package hr.smartduplicatecleaner.ui.results

import android.content.IntentSender
import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import hr.smartduplicatecleaner.AppContainer
import hr.smartduplicatecleaner.R
import hr.smartduplicatecleaner.core.logic.DeleteOutcome
import hr.smartduplicatecleaner.core.logic.DeletionPlan
import hr.smartduplicatecleaner.core.logic.DeletionPlanner
import hr.smartduplicatecleaner.core.logic.DeletionReport
import hr.smartduplicatecleaner.core.logic.DeletionRunner
import hr.smartduplicatecleaner.core.logic.FailureReason
import hr.smartduplicatecleaner.core.logic.GroupDecision
import hr.smartduplicatecleaner.core.logic.PlanResult
import hr.smartduplicatecleaner.core.logic.SelectionState
import hr.smartduplicatecleaner.core.logic.Suggestion
import hr.smartduplicatecleaner.core.model.DuplicateGroup
import hr.smartduplicatecleaner.core.model.FileCategory
import hr.smartduplicatecleaner.core.model.GroupType
import hr.smartduplicatecleaner.core.model.ScannedFile
import hr.smartduplicatecleaner.core.model.SourceType
import hr.smartduplicatecleaner.data.settings.DeletionMode
import hr.smartduplicatecleaner.ui.components.FileStatus
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Filtri rezultata (kartice na vrhu zaslona). */
enum class ResultFilter { ALL, EXACT, SAME_NAME, SIMILAR_PHOTOS, VIDEO, AUDIO, DOCUMENTS, OTHER }

data class ReviewState(
    val loading: Boolean = true,
    val files: Map<String, ScannedFile> = emptyMap(),
    val groups: List<DuplicateGroup> = emptyList(),
    val decisions: Map<String, GroupDecision> = emptyMap(),
    val marked: Set<String> = emptySet(),
    val filter: ResultFilter = ResultFilter.ALL
) {
    val visibleGroups: List<DuplicateGroup>
        get() = groups.filter { g ->
            when (filter) {
                ResultFilter.ALL -> true
                ResultFilter.EXACT -> g.type == GroupType.EXACT
                ResultFilter.SAME_NAME -> g.type == GroupType.SAME_NAME
                ResultFilter.SIMILAR_PHOTOS -> g.type == GroupType.VISUAL || g.type == GroupType.SIMILAR
                ResultFilter.VIDEO -> g.category == FileCategory.VIDEO
                ResultFilter.AUDIO -> g.category == FileCategory.AUDIO
                ResultFilter.DOCUMENTS -> g.category == FileCategory.DOCUMENT
                ResultFilter.OTHER -> g.category == FileCategory.ARCHIVE || g.category == FileCategory.OTHER
            }
        }

    val markedBytes: Long get() = marked.sumOf { files[it]?.sizeBytes ?: 0L }

    /** Datoteke u trenutačno odabranoj kategoriji (null = sve kategorije). */
    val scopeKeys: Set<String>? get() = if (filter == ResultFilter.ALL) null else visibleGroups.flatMap { it.fileKeys }.toSet()

    /** Označene datoteke koje će se obrisati – samo one iz odabrane kategorije. */
    val markedInScope: Set<String> get() = scopeKeys?.let { k -> marked.filter { it in k }.toSet() } ?: marked
    val markedInScopeBytes: Long get() = markedInScope.sumOf { files[it]?.sizeBytes ?: 0L }

    fun countFor(f: ResultFilter): Int = copy(filter = f).visibleGroups.size

    fun status(groupId: String, key: String): FileStatus {
        if (key in marked) {
            val suggested = decisions[groupId]?.members?.firstOrNull { it.fileKey == key }?.suggestion == Suggestion.DELETE
            return if (suggested) FileStatus.DELETE_SUGGESTED else FileStatus.DELETE_MANUAL
        }
        val group = groups.firstOrNull { it.id == groupId }
        // Grupa bez ijedne oznake koja čeka odluku (nema jasnog pobjednika / samo slične).
        if (group != null && decisions[groupId]?.needsManual == true && group.fileKeys.none { it in marked }) return FileStatus.PENDING
        return FileStatus.KEEP
    }
}

/** Stanje izvršavanja brisanja. */
sealed class DeletionUi {
    data object Idle : DeletionUi()
    data class Running(val done: Int, val total: Int) : DeletionUi()
    /** Android traži potvrdu u sistemskom dijalogu (MediaStore). */
    data class AwaitingConsent(val intentSender: IntentSender, val count: Int) : DeletionUi()
    data class Finished(val report: DeletionReport) : DeletionUi()
}

/**
 * Zajednički ViewModel za rezultate, detalje grupe, pregled prije brisanja i brisanje.
 * Oznake se čuvaju u [SelectionState] koji jamči da u svakoj grupi ostane barem jedna datoteka.
 */
class ReviewViewModel(private val c: AppContainer) : ViewModel() {

    private val _state = MutableStateFlow(ReviewState())
    val state: StateFlow<ReviewState> = _state.asStateFlow()

    private val _messages = MutableSharedFlow<Int>(extraBufferCapacity = 4)
    /** Kratke poruke (ID string resursa) za Snackbar. */
    val messages: SharedFlow<Int> = _messages.asSharedFlow()

    private var selection = SelectionState(emptyList())
    private var saveJob: Job? = null

    private val _plan = MutableStateFlow<PlanResult?>(null)
    val plan: StateFlow<PlanResult?> = _plan.asStateFlow()

    private val _deletion = MutableStateFlow<DeletionUi>(DeletionUi.Idle)
    val deletion: StateFlow<DeletionUi> = _deletion.asStateFlow()

    init { reload() }

    fun reload() {
        viewModelScope.launch {
            _state.update { it.copy(loading = true) }
            val data = withContext(Dispatchers.IO) { c.results.load() }
            selection = SelectionState(data.groups, data.marked)
            _state.update {
                it.copy(loading = false, files = data.files, groups = data.groups, decisions = data.decisions, marked = selection.marked)
            }
        }
    }

    private var loadedScanTime: Long? = null

    /** Ponovno učitavanje samo ako postoji novije skeniranje od učitanog (ne gubi nespremljene oznake). */
    fun ensureFresh(scanFinishedAt: Long?) {
        if (scanFinishedAt != null && scanFinishedAt != loadedScanTime) {
            loadedScanTime = scanFinishedAt
            reload()
        }
    }

    fun setFilter(f: ResultFilter) = _state.update { it.copy(filter = f) }

    fun toggle(key: String) {
        when (selection.toggle(key)) {
            SelectionState.Result.BLOCKED_LAST_FILE -> _messages.tryEmit(R.string.msg_last_file_blocked)
            else -> Unit
        }
        publish()
    }

    /** "Zadrži ovu datoteku" – jedan dodir: ova se čuva, ostale u grupi označavaju za brisanje. */
    fun keepOnly(groupId: String, key: String) {
        val skipped = selection.keepOnly(groupId, key)
        if (skipped > 0) _messages.tryEmit(R.string.msg_some_skipped)
        publish()
    }

    fun clearGroup(groupId: String) { selection.clearGroup(groupId); publish() }

    fun clearAll() { selection.clearAll(); publish() }

    /** Primjena automatskih prijedloga; [onlyConfirmed] = samo potvrđeni (SHA-256) duplikati. */
    fun applySuggestions(onlyConfirmed: Boolean) {
        if (onlyConfirmed) selection.clearAll()
        val n = selection.applySuggestions(_state.value.decisions.values, onlyConfirmed)
        publish()
        if (n == 0) _messages.tryEmit(R.string.msg_nothing_to_mark)
    }

    private fun publish() {
        val marked = selection.marked
        _state.update { it.copy(marked = marked) }
        saveJob?.cancel()
        saveJob = viewModelScope.launch(Dispatchers.IO) {
            delay(400) // odgoda: više brzih dodira sprema se jednom
            c.results.saveMarks(marked)
            c.results.refreshSummary()
        }
    }

    // ---------- Pregled i potvrda brisanja ----------

    /** Izrada konačnog plana; plan se "zamrzava" i točno on se izvršava nakon potvrde. */
    fun preparePlan() {
        // Briše se samo u kategoriji u kojoj je korisnik pokrenuo brisanje; ostale oznake ostaju netaknute.
        _plan.value = DeletionPlanner.build(selection, _state.value.files, _state.value.scopeKeys)
    }

    fun execute(plan: DeletionPlan) {
        if (_deletion.value is DeletionUi.Running || _deletion.value is DeletionUi.AwaitingConsent) return
        viewModelScope.launch {
            val mode = c.settings.current().deletionMode
            val recoverable = mode == DeletionMode.RECOVERABLE
            val direct = plan.items.filter { it.source != SourceType.MEDIA_STORE }
            val media = plan.items.filter { it.source == SourceType.MEDIA_STORE }
            _deletion.value = DeletionUi.Running(0, plan.count)

            // 1) SAF i datotečni sustav – izravno, jedna po jedna.
            val directReport = withContext(Dispatchers.IO) {
                DeletionRunner.run(
                    DeletionPlan(direct), c.deletionManager.directDeleter(recoverable), recoverable,
                    stillValid = { c.deletionManager.validity(it) },
                    onProgress = { done, _ -> _deletion.value = DeletionUi.Running(done, plan.count) }
                )
            }
            succeeded.clear(); failed.clear()
            succeeded += directReport.succeeded
            failed += directReport.failed

            // 2) MediaStore – provjera i sistemski dijalog u serijama.
            val (valid, invalid) = withContext(Dispatchers.IO) {
                media.map { it to c.deletionManager.validity(it) }.partition { it.second == null }
            }
            invalid.forEach { (f, r) -> failed += f to DeleteOutcome.Failed(r!!) }
            mediaQueue.clear()
            mediaQueue.addAll(valid.map { it.first }.chunked(MEDIA_BATCH))
            pendingRecoverable = recoverable
            nextMediaBatch()
        }
    }

    private val succeeded = mutableListOf<ScannedFile>()
    private val failed = mutableListOf<Pair<ScannedFile, DeleteOutcome.Failed>>()
    private val mediaQueue = ArrayDeque<List<ScannedFile>>()
    private var currentBatch: List<ScannedFile> = emptyList()
    private var pendingRecoverable = true

    private fun nextMediaBatch() {
        val batch = mediaQueue.removeFirstOrNull()
        if (batch == null) {
            finish()
            return
        }
        currentBatch = batch
        consentLaunched = false
        try {
            val pi = c.deletionManager.mediaRequest(batch.map { Uri.parse(it.uri) }, trash = pendingRecoverable)
            _deletion.value = DeletionUi.AwaitingConsent(pi.intentSender, batch.size)
        } catch (e: Exception) {
            batch.forEach { failed += it to DeleteOutcome.Failed(FailureReason.PERMISSION_DENIED, e.message) }
            nextMediaBatch()
        }
    }

    private var consentLaunched = false

    /** Vraća true samo jednom po seriji – sprječava dvostruko otvaranje dijaloga (npr. nakon rotacije). */
    fun claimConsentLaunch(): Boolean {
        if (consentLaunched) return false
        consentLaunched = true
        return true
    }

    /** Rezultat sistemskog dijaloga; stvarni ishod provjerava se za svaku datoteku. */
    fun onConsentResult(approved: Boolean) {
        val batch = currentBatch
        viewModelScope.launch {
            val outcomes = withContext(Dispatchers.IO) { c.deletionManager.verifyMedia(batch, pendingRecoverable, approved) }
            outcomes.forEach { (f, o) ->
                when (o) {
                    is DeleteOutcome.Done -> succeeded += f
                    is DeleteOutcome.Failed -> failed += f to o
                }
            }
            nextMediaBatch()
        }
    }

    private fun finish() {
        val report = DeletionReport(succeeded.toList(), failed.toList(), pendingRecoverable)
        viewModelScope.launch {
            withContext(Dispatchers.IO) { c.results.removeFiles(report.succeeded.map { it.key }) }
            _deletion.value = DeletionUi.Finished(report)
            _plan.value = null
            reload()
        }
    }

    fun resetDeletion() { _deletion.value = DeletionUi.Idle }

    companion object {
        private const val MEDIA_BATCH = 300
    }
}

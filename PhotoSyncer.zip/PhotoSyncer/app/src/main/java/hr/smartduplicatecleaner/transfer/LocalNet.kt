package hr.smartduplicatecleaner.transfer

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.wifi.WifiInfo
import android.net.wifi.WifiManager
import android.os.Build
import android.provider.Settings
import java.net.DatagramSocket
import java.net.Inet4Address
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.NetworkInterface

/**
 * Lokalna mreža između dva mobitela: žarišna točka (hotspot) JEDNOG od njih – svejedno kojeg – ili isti Wi-Fi.
 * Prijenos ide samo lokalno; mobilni podaci se za prijenos ne troše.
 */
object LocalNet {

    /** Stanje mreže ovog mobitela za prikaz korisniku. */
    data class Status(
        /** Mobitel je spojen na Wi-Fi (npr. na žarišnu točku drugog mobitela). */
        val wifiConnected: Boolean,
        /** Na ovom mobitelu je uključena žarišna točka. */
        val hotspotOn: Boolean,
        /** Lokalne IPv4 adrese (prva je glavna). */
        val addresses: List<String>,
        /** Frekvencija Wi-Fi veze u MHz (samo kad je mobitel spojen na Wi-Fi / tuđu žarišnu točku). */
        val wifiFrequencyMhz: Int? = null,
        /** Brzina Wi-Fi veze u Mbit/s (teoretska, stvarni prijenos je oko 40–60 % toga). */
        val wifiLinkMbps: Int? = null
    ) {
        val ready: Boolean get() = addresses.isNotEmpty()
        val is24GHz: Boolean get() = (wifiFrequencyMhz ?: 0) in 2400..2500
        /** Pojas za prikaz: "2,4 GHz", "5 GHz", "6 GHz" ili null. */
        val band: String? get() {
            val f = wifiFrequencyMhz ?: return null
            return when (f) {
                in 2400..2500 -> "2,4 GHz"
                in 4900..5899 -> "5 GHz"
                in 5925..7125 -> "6 GHz"
                else -> null
            }
        }
    }

    /** Podaci o Wi-Fi vezi (frekvencija, brzina veze) – ne traže dopuštenje za lokaciju. */
    @Suppress("DEPRECATION")
    private fun wifiInfo(context: Context, network: Network?): WifiInfo? {
        if (network == null) return null
        val cm = context.getSystemService(ConnectivityManager::class.java)
        val fromCaps = try { cm?.getNetworkCapabilities(network)?.transportInfo as? WifiInfo } catch (e: Exception) { null }
        if (fromCaps != null && fromCaps.frequency > 0) return fromCaps
        return try { context.applicationContext.getSystemService(WifiManager::class.java)?.connectionInfo } catch (e: Exception) { null }
    }

    /** Wi-Fi mreža na koju je mobitel spojen (kao klijent), ili null. */
    @Suppress("DEPRECATION")
    fun wifiNetwork(context: Context): Network? {
        val cm = context.getSystemService(ConnectivityManager::class.java) ?: return null
        return cm.allNetworks.firstOrNull { n ->
            cm.getNetworkCapabilities(n)?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true
        }
    }

    private fun wifiAddresses(context: Context, network: Network?): List<String> {
        if (network == null) return emptyList()
        val cm = context.getSystemService(ConnectivityManager::class.java) ?: return emptyList()
        return cm.getLinkProperties(network)?.linkAddresses
            ?.map { it.address }?.filter { it is Inet4Address && !it.isLoopbackAddress }
            ?.mapNotNull { it.hostAddress } ?: emptyList()
    }

    /** Sučelja mobilne mreže, VPN-a i sl. – ne koriste se za lokalni prijenos. */
    private fun ignored(name: String) = listOf("rmnet", "ccmni", "dummy", "tun", "ppp", "lo", "v4-", "clat", "ipsec", "seth", "pdp")
        .any { name.startsWith(it) }

    private fun localInterfaces(): List<Pair<NetworkInterface, Inet4Address>> = try {
        NetworkInterface.getNetworkInterfaces()?.toList().orEmpty()
            .filter { ni -> !ignored(ni.name) && (try { ni.isUp && !ni.isLoopback } catch (e: Exception) { true }) }
            .flatMap { ni -> ni.inetAddresses.toList().filterIsInstance<Inet4Address>().filter { it.isSiteLocalAddress }.map { ni to it } }
    } catch (e: Exception) {
        emptyList()
    }

    fun status(context: Context): Status {
        val wifi = wifiNetwork(context)
        val wifiAddr = wifiAddresses(context, wifi)
        val others = localInterfaces().mapNotNull { it.second.hostAddress }.filter { it !in wifiAddr }
        // Adrese izvan Wi-Fi veze na Wi-Fi sučeljima = žarišna točka ovog mobitela (ap0, swlan0, wlan1…).
        val info = if (wifiAddr.isNotEmpty()) wifiInfo(context, wifi) else null
        val link = info?.let { maxOf(it.txLinkSpeedMbps, it.rxLinkSpeedMbps, it.linkSpeed) }?.takeIf { it > 0 }
        return Status(
            wifiConnected = wifi != null && wifiAddr.isNotEmpty(),
            hotspotOn = others.isNotEmpty(),
            addresses = (wifiAddr + others).distinct(),
            wifiFrequencyMhz = info?.frequency?.takeIf { it > 0 },
            wifiLinkMbps = link
        )
    }

    /**
     * Wi-Fi mreža kroz koju treba ići promet prema [address] (adresa je u podmreži Wi-Fi veze), ili null
     * (adresa je u mreži žarišne točke ovog mobitela – tada sustav sam bira ispravno sučelje).
     */
    fun wifiNetworkFor(context: Context, address: InetAddress): Network? {
        if (address !is Inet4Address) return null
        val net = wifiNetwork(context) ?: return null
        val cm = context.getSystemService(ConnectivityManager::class.java) ?: return null
        val lp = cm.getLinkProperties(net) ?: return null
        val target = toInt(address)
        val inSubnet = lp.linkAddresses.any { la ->
            val a = la.address
            if (a !is Inet4Address) return@any false
            val bits = la.prefixLength.coerceIn(0, 32)
            val mask = if (bits == 0) 0 else (-1 shl (32 - bits))
            (toInt(a) and mask) == (target and mask)
        }
        return if (inSubnet) net else null
    }

    private fun toInt(a: Inet4Address): Int = a.address.fold(0) { acc, b -> (acc shl 8) or (b.toInt() and 0xFF) }

    /** Je li tekst ispravna IPv4 adresa (npr. 192.168.43.1). */
    fun isIpv4(text: String): Boolean {
        val parts = text.trim().split('.')
        return parts.size == 4 && parts.all { p -> p.isNotEmpty() && p.length <= 3 && p.all { it.isDigit() } && p.toInt() <= 255 }
    }

    /** Pristupnik (gateway) Wi-Fi mreže – kad je drugi mobitel žarišna točka, to je njegova adresa. */
    fun gateway(context: Context): String? {
        val net = wifiNetwork(context) ?: return null
        val cm = context.getSystemService(ConnectivityManager::class.java) ?: return null
        return cm.getLinkProperties(net)?.routes
            ?.firstOrNull { it.isDefaultRoute && it.gateway is Inet4Address }
            ?.gateway?.hostAddress
    }

    /**
     * Soketi i adrese za traženje primatelja:
     *  - soket vezan uz Wi-Fi mrežu (kad je ovaj mobitel spojen na žarišnu točku/Wi-Fi bez interneta,
     *    Android bi inače promet slao mobilnom mrežom)
     *  - nevezani soket za mrežu žarišne točke ovog mobitela
     */
    fun discoveryTargets(context: Context, port: Int): List<Pair<DatagramSocket, List<InetSocketAddress>>> {
        val broadcasts = localInterfaces().mapNotNull { (ni, addr) ->
            ni.interfaceAddresses.firstOrNull { it.address == addr }?.broadcast
        }.distinct()
        val all = (broadcasts + InetAddress.getByName("255.255.255.255")).map { InetSocketAddress(it, port) }
        val result = mutableListOf<Pair<DatagramSocket, List<InetSocketAddress>>>()
        wifiNetwork(context)?.let { net ->
            try {
                val s = DatagramSocket()
                net.bindSocket(s)
                val gw = gateway(context)?.let { listOf(InetSocketAddress(it, port)) } ?: emptyList()
                result += s to (all + gw)
            } catch (e: Exception) { }
        }
        try { result += DatagramSocket() to all } catch (e: Exception) { }
        return result
    }

    /**
     * Rezervno traženje primatelja kad automatsko (UDP) ne uspije: provjera TCP porta na pristupniku i na
     * svim adresama malih lokalnih podmreža (/24 ili manjih – takve koriste žarišne točke). Traje 1–3 s.
     * Samo otvaranje veze ne troši pokušaje koda kod primatelja.
     */
    fun sweep(context: Context, port: Int, timeoutMs: Int = 600, cancelled: () -> Boolean = { false }): List<String> {
        val own = HashSet<String>()
        val hosts = LinkedHashMap<String, Network?>()
        gateway(context)?.let { gw -> hosts[gw] = wifiNetworkFor(context, InetAddress.getByName(gw)) }
        for ((ni, addr) in localInterfaces()) {
            addr.hostAddress?.let { own += it }
            val bits = ni.interfaceAddresses.firstOrNull { it.address == addr }?.networkPrefixLength?.toInt() ?: continue
            if (bits !in 24..30) continue
            val net = wifiNetworkFor(context, addr)
            val base = toInt(addr) and (-1 shl (32 - bits))
            for (i in 1 until (1 shl (32 - bits)) - 1) hosts.putIfAbsent(intToIp(base + i), net)
        }
        own.forEach { hosts.remove(it) }
        if (hosts.isEmpty()) return emptyList()
        val open = java.util.Collections.synchronizedSet(HashSet<String>())
        val pool = java.util.concurrent.Executors.newFixedThreadPool(64)
        try {
            hosts.map { (host, net) ->
                pool.submit(Runnable {
                    if (cancelled()) return@Runnable
                    try {
                        java.net.Socket().use { s ->
                            net?.bindSocket(s)
                            s.connect(InetSocketAddress(host, port), timeoutMs)
                        }
                        open += host
                    } catch (e: Exception) {
                    }
                })
            }.forEach { f -> try { f.get() } catch (e: Exception) { } }
        } finally {
            pool.shutdownNow()
        }
        return hosts.keys.filter { it in open } // pristupnik prvi
    }

    private fun intToIp(v: Int) = "${(v ushr 24) and 255}.${(v ushr 16) and 255}.${(v ushr 8) and 255}.${v and 255}"

    /** Wi-Fi lock za primanje upita i na ugašenom zaslonu. */
    fun multicastLock(context: Context): WifiManager.MulticastLock? = try {
        context.applicationContext.getSystemService(WifiManager::class.java)
            ?.createMulticastLock("PhotoSync:discovery")?.apply { setReferenceCounted(false); acquire() }
    } catch (e: Exception) {
        null
    }

    // ---------- Prečaci u postavke sustava ----------

    /** Postavke žarišne točke (Android nema javni izravni prečac, pa redom pokušavamo poznate). */
    fun openHotspotSettings(context: Context) {
        val candidates = listOf(
            Intent("android.settings.TETHER_SETTINGS"),
            Intent().setClassName("com.android.settings", "com.android.settings.TetherSettings"),
            Intent().setClassName("com.android.settings", "com.android.settings.Settings\$TetherSettingsActivity"),
            Intent(Settings.ACTION_WIRELESS_SETTINGS)
        )
        for (i in candidates) {
            try {
                context.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); return
            } catch (e: ActivityNotFoundException) {
            } catch (e: SecurityException) {
            }
        }
    }

    fun openWifiSettings(context: Context) {
        val i = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) Intent(Settings.Panel.ACTION_WIFI) else Intent(Settings.ACTION_WIFI_SETTINGS)
        try { context.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (e: Exception) {
            try { context.startActivity(Intent(Settings.ACTION_WIFI_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (x: Exception) { }
        }
    }
}

package hr.smartduplicatecleaner.data.settings

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.MutablePreferences
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import hr.smartduplicatecleaner.core.dates.DayMonthOrder
import hr.smartduplicatecleaner.core.dates.IntervalBasis
import hr.smartduplicatecleaner.core.transfer.TransferCategory
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

/** Postavke dijela "Ispravak datuma po nazivu". */
data class DateFixPrefs(
    val order: DayMonthOrder = DayMonthOrder.STANDARD,
    /** Ručno zadani oblici naziva, npr. "IMG-yyyyMMdd-WA*". */
    val patterns: List<String> = emptyList(),
    val timestamps: Boolean = true,
    val intervalEnabled: Boolean = false,
    val from: Long? = null,
    val to: Long? = null,
    val basis: IntervalBasis = IntervalBasis.NAME_DATE,
    /** Odabrane mape (relativne putanje); prazno = sve mape. */
    val folders: Set<String> = emptySet(),
    /** Upis datuma snimanja (EXIF za fotografije, metapodaci za MP4/MOV). */
    val writeMetadata: Boolean = true,
    /** Upis datuma izmjene datoteke (samo uz pristup svim datotekama). */
    val writeModified: Boolean = true,
    val compareTime: Boolean = false,
    /** Koje vrste se analiziraju. */
    val includePhotos: Boolean = true,
    val includeVideos: Boolean = true
)

/** Postavke dijela "Slanje / primanje". */
data class TransferPrefs(
    val categories: Set<TransferCategory> = setOf(
        TransferCategory.PHOTOS, TransferCategory.VIDEOS, TransferCategory.AUDIO, TransferCategory.DOCUMENTS
    ),
    val intervalEnabled: Boolean = false,
    val from: Long? = null,
    val to: Long? = null,
    /** Usluga u prvom planu + wake lock: prijenos se ne prekida kad se zaslon ugasi ili se izađe iz aplikacije. */
    val background: Boolean = true,
    val keepScreenOn: Boolean = true,
    val skipExisting: Boolean = true,
    /** Unutar PhotoSyncer/<vrsta>/ zadržava se naziv izvorne mape (npr. PhotoSyncer/Fotografije/Camera/). */
    val keepSubfolders: Boolean = false,
    /** Primljene datoteke idu u mapu istog naziva kao na starom mobitelu (npr. DCIM/Camera) ako ona postoji. */
    val sameFolders: Boolean = false,
    /** Ručno odabrana mapa za primanje (SAF URI); null = zadana mapa aplikacije. */
    val customTree: String? = null
)

private val Context.featureStore: DataStore<Preferences> by preferencesDataStore(name = "features")

class FeatureSettingsRepository(private val context: Context) {

    private object K {
        val DF_ORDER = stringPreferencesKey("df_order")
        val DF_PATTERNS = stringPreferencesKey("df_patterns")
        val DF_TIMESTAMPS = booleanPreferencesKey("df_timestamps")
        val DF_INTERVAL = booleanPreferencesKey("df_interval")
        val DF_FROM = longPreferencesKey("df_from")
        val DF_TO = longPreferencesKey("df_to")
        val DF_BASIS = stringPreferencesKey("df_basis")
        val DF_FOLDERS = stringSetPreferencesKey("df_folders")
        val DF_META = booleanPreferencesKey("df_meta")
        val DF_MOD = booleanPreferencesKey("df_mod")
        val DF_TIME = booleanPreferencesKey("df_time")
        val DF_PHOTOS = booleanPreferencesKey("df_photos")
        val DF_VIDEOS = booleanPreferencesKey("df_videos")
        val TR_SUBFOLDERS = booleanPreferencesKey("tr_subfolders")
        val TR_CATS = stringSetPreferencesKey("tr_cats")
        val TR_INTERVAL = booleanPreferencesKey("tr_interval")
        val TR_FROM = longPreferencesKey("tr_from")
        val TR_TO = longPreferencesKey("tr_to")
        val TR_BG = booleanPreferencesKey("tr_bg")
        val TR_SCREEN = booleanPreferencesKey("tr_screen")
        val TR_SKIP = booleanPreferencesKey("tr_skip")
        val TR_SAME = booleanPreferencesKey("tr_same_folders")
        val TR_TREE = stringPreferencesKey("tr_tree")
    }

    private inline fun <reified E : Enum<E>> enumOf(v: String?, d: E): E = v?.let { s -> enumValues<E>().firstOrNull { it.name == s } } ?: d

    val dateFix: Flow<DateFixPrefs> = context.featureStore.data.map { readDateFix(it) }
    val transfer: Flow<TransferPrefs> = context.featureStore.data.map { readTransfer(it) }

    suspend fun currentDateFix(): DateFixPrefs = dateFix.first()
    suspend fun currentTransfer(): TransferPrefs = transfer.first()

    private fun readDateFix(p: Preferences): DateFixPrefs {
        val d = DateFixPrefs()
        return DateFixPrefs(
            order = enumOf(p[K.DF_ORDER], d.order),
            patterns = p[K.DF_PATTERNS]?.split('\n')?.filter { it.isNotBlank() } ?: d.patterns,
            timestamps = p[K.DF_TIMESTAMPS] ?: d.timestamps,
            intervalEnabled = p[K.DF_INTERVAL] ?: d.intervalEnabled,
            from = p[K.DF_FROM]?.takeIf { it >= 0 },
            to = p[K.DF_TO]?.takeIf { it >= 0 },
            basis = enumOf(p[K.DF_BASIS], d.basis),
            folders = p[K.DF_FOLDERS] ?: d.folders,
            writeMetadata = p[K.DF_META] ?: d.writeMetadata,
            writeModified = p[K.DF_MOD] ?: d.writeModified,
            compareTime = p[K.DF_TIME] ?: d.compareTime,
            includePhotos = p[K.DF_PHOTOS] ?: d.includePhotos,
            includeVideos = p[K.DF_VIDEOS] ?: d.includeVideos
        )
    }

    private fun readTransfer(p: Preferences): TransferPrefs {
        val d = TransferPrefs()
        return TransferPrefs(
            categories = p[K.TR_CATS]?.mapNotNull { n -> TransferCategory.entries.firstOrNull { it.name == n } }?.toSet() ?: d.categories,
            intervalEnabled = p[K.TR_INTERVAL] ?: d.intervalEnabled,
            from = p[K.TR_FROM]?.takeIf { it >= 0 },
            to = p[K.TR_TO]?.takeIf { it >= 0 },
            background = p[K.TR_BG] ?: d.background,
            keepScreenOn = p[K.TR_SCREEN] ?: d.keepScreenOn,
            skipExisting = p[K.TR_SKIP] ?: d.skipExisting,
            keepSubfolders = p[K.TR_SUBFOLDERS] ?: d.keepSubfolders,
            sameFolders = p[K.TR_SAME] ?: d.sameFolders,
            customTree = p[K.TR_TREE]?.takeIf { it.isNotEmpty() }
        )
    }

    suspend fun updateDateFix(transform: (DateFixPrefs) -> DateFixPrefs) {
        context.featureStore.edit { p ->
            val s = transform(readDateFix(p))
            p[K.DF_ORDER] = s.order.name
            p[K.DF_PATTERNS] = s.patterns.joinToString("\n")
            p[K.DF_TIMESTAMPS] = s.timestamps
            p[K.DF_INTERVAL] = s.intervalEnabled
            p[K.DF_FROM] = s.from ?: -1L
            p[K.DF_TO] = s.to ?: -1L
            p[K.DF_BASIS] = s.basis.name
            p[K.DF_FOLDERS] = s.folders
            p[K.DF_META] = s.writeMetadata
            p[K.DF_MOD] = s.writeModified
            p[K.DF_TIME] = s.compareTime
            p[K.DF_PHOTOS] = s.includePhotos
            p[K.DF_VIDEOS] = s.includeVideos
        }
    }

    suspend fun updateTransfer(transform: (TransferPrefs) -> TransferPrefs) {
        context.featureStore.edit { p: MutablePreferences ->
            val s = transform(readTransfer(p))
            p[K.TR_CATS] = s.categories.map { it.name }.toSet()
            p[K.TR_INTERVAL] = s.intervalEnabled
            p[K.TR_FROM] = s.from ?: -1L
            p[K.TR_TO] = s.to ?: -1L
            p[K.TR_BG] = s.background
            p[K.TR_SCREEN] = s.keepScreenOn
            p[K.TR_SKIP] = s.skipExisting
            p[K.TR_SUBFOLDERS] = s.keepSubfolders
            p[K.TR_SAME] = s.sameFolders
            p[K.TR_TREE] = s.customTree ?: ""
        }
    }
}

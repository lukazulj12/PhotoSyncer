package hr.smartduplicatecleaner.transfer

import android.content.Context
import android.content.Intent
import android.net.Network
import android.net.wifi.WifiManager
import android.os.Build
import androidx.core.content.ContextCompat
import hr.smartduplicatecleaner.R
import hr.smartduplicatecleaner.core.transfer.Discovery
import hr.smartduplicatecleaner.core.transfer.PairingCode
import hr.smartduplicatecleaner.core.transfer.TransferCategory
import hr.smartduplicatecleaner.core.transfer.TransferException
import hr.smartduplicatecleaner.core.transfer.TransferItem
import hr.smartduplicatecleaner.core.transfer.TransferProgress
import hr.smartduplicatecleaner.core.transfer.TransferReceiver
import hr.smartduplicatecleaner.core.transfer.TransferResult
import hr.smartduplicatecleaner.core.transfer.TransferSender
import hr.smartduplicatecleaner.data.settings.FeatureSettingsRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket
import java.util.concurrent.atomic.AtomicBoolean

enum class TransferRole { SEND, RECEIVE }

enum class TransferFailure {
    /** Mobitel nije spojen ni na Wi-Fi ni na žarišnu točku, niti je žarišna točka uključena. */
    NO_NETWORK,
    /** Primatelj nije pronađen u mreži (moguć ručni unos IP adrese). */
    NOT_FOUND,
    CONNECT_FAILED, AUTH_FAILED, BUSY, NO_SPACE, PORT_IN_USE,
    /** Primatelj je zaustavio primanje nakon previše pogrešnih kodova. */
    TOO_MANY_ATTEMPTS,
    BAD_ADDRESS, UNKNOWN
}

sealed class TransferState {
    data object Idle : TransferState()
    /** [searching] = pošiljatelj traži primatelja u mreži. */
    data class Preparing(val role: TransferRole, val searching: Boolean = false) : TransferState()
    /** Primatelj čeka pošiljatelja. */
    data class Waiting(val code: String) : TransferState()
    data class Active(val role: TransferRole, val progress: TransferProgress, val peer: String) : TransferState()
    /**
     * Završeno. Kod primatelja [listeningCode] != null znači da primanje i dalje radi (pošiljatelj može
     * ponovno poslati neuspjele stavke) dok korisnik ne pritisne "Gotovo".
     */
    data class Finished(
        val role: TransferRole,
        val result: TransferResult,
        val apps: List<ReceivedApp>,
        val listeningCode: String? = null
    ) : TransferState()
    data class Failed(val role: TransferRole, val reason: TransferFailure, val freeBytes: Long = -1) : TransferState()
    /** Test brzine mreže (bez diska). [bytesPerSecond] je trenutačna, a nakon završetka prosječna brzina. */
    data class SpeedTest(val bytesPerSecond: Long, val running: Boolean, val peer: String) : TransferState()

    val isBusy: Boolean get() = this is Preparing || this is Waiting || this is Active || (this is SpeedTest && running)
}

/**
 * Upravlja prijenosom u opsegu aplikacije (nastavlja raditi kad korisnik napusti zaslon).
 *
 * Veza: oba mobitela u istoj lokalnoj mreži – žarišna točka (hotspot) jednog od njih, svejedno kojeg,
 * ili isti Wi-Fi. Pošiljatelj automatski pronalazi primatelja (UDP upit), a ako to ne uspije,
 * korisnik može upisati IP adresu prikazanu na primatelju.
 *
 * Uz uključen rad u pozadini pokreće [TransferService] (obavijest + wake lock + Wi-Fi lock).
 */
class TransferManager(private val context: Context, private val features: FeatureSettingsRepository) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val _state = MutableStateFlow<TransferState>(TransferState.Idle)
    val state: StateFlow<TransferState> = _state.asStateFlow()

    private var job: Job? = null
    private var receiver: TransferReceiver? = null
    private var responder: Discovery.Responder? = null
    private val replySockets = HashMap<Network, DatagramSocket>()
    private var multicast: android.net.wifi.WifiManager.MulticastLock? = null
    private val cancelled = AtomicBoolean(false)

    /** Zadnje slanje – za ponovno slanje neuspjelih stavki. */
    private var lastCode: String? = null
    private var lastHost: String? = null

    private var perfLock: WifiManager.WifiLock? = null
    private var lowLatencyLock: WifiManager.WifiLock? = null

    init {
        // Dok traje prijenos ili test, Wi-Fi ne smije prelaziti u štedni način (to najviše usporava prijenos).
        scope.launch { state.collect { s -> if (s.isBusy) acquireWifiLocks() else releaseWifiLocks() } }
    }

    /**
     * WIFI_MODE_FULL_LOW_LATENCY (Android 10+) isključuje štedni način Wi-Fi-ja dok je aplikacija na zaslonu;
     * HIGH_PERF dodatno pomaže na starijim uređajima i u pozadini (neki proizvođači ga i dalje poštuju).
     */
    @Suppress("DEPRECATION")
    private fun acquireWifiLocks() {
        val wm = context.applicationContext.getSystemService(WifiManager::class.java) ?: return
        if (lowLatencyLock == null) try {
            lowLatencyLock = wm.createWifiLock(WifiManager.WIFI_MODE_FULL_LOW_LATENCY, "PhotoSync:lowlatency")
                .apply { setReferenceCounted(false); acquire() }
        } catch (e: Exception) { }
        if (perfLock == null) try {
            perfLock = wm.createWifiLock(WifiManager.WIFI_MODE_FULL_HIGH_PERF, "PhotoSync:perf")
                .apply { setReferenceCounted(false); acquire() }
        } catch (e: Exception) { }
    }

    private fun releaseWifiLocks() {
        listOf(lowLatencyLock, perfLock).forEach { l -> try { if (l?.isHeld == true) l.release() } catch (e: Exception) { } }
        lowLatencyLock = null
        perfLock = null
    }

    /** Provjera mreže; null = ovaj mobitel je u nekoj lokalnoj mreži. */
    fun precheck(): TransferFailure? = if (LocalNet.status(context).ready) null else TransferFailure.NO_NETWORK

    // ---------- Primanje ----------

    fun startReceiving() {
        if (_state.value.isBusy) return
        stopReceiverInternal()
        cancelled.set(false)
        _state.value = TransferState.Preparing(TransferRole.RECEIVE)
        job = scope.launch {
            val prefs = features.currentTransfer()
            if (prefs.background) startService()
            val code = PairingCode.generate()
            val s = AndroidTransferSink(
                context,
                ReceiveOptions(prefs.skipExisting, prefs.sameFolders, prefs.customTree, prefs.keepSubfolders) { folderName(it) }
            )
            var peer = ""
            val r = TransferReceiver(code, s, object : TransferReceiver.Listener {
                override fun onSessionStarted(deviceName: String, files: Int, bytes: Long) {
                    peer = deviceName
                    // Nova sesija (npr. ponovno slanje neuspjelih) – usluga se ponovno pokreće ako je bila zaustavljena.
                    if (prefs.background) startService()
                    _state.value = TransferState.Active(TransferRole.RECEIVE, TransferProgress(0, files, 0, bytes, 0, System.currentTimeMillis()), deviceName)
                }
                override fun onProgress(progress: TransferProgress) {
                    _state.value = TransferState.Active(TransferRole.RECEIVE, progress, peer)
                }
                override fun onSessionFinished(result: TransferResult) {
                    // Primanje ostaje uključeno (isti kod) – pošiljatelj može ponovno poslati neuspjele stavke.
                    _state.value = TransferState.Finished(TransferRole.RECEIVE, result, s.receivedApps(), listeningCode = code)
                }
                override fun onRejectedNoSpace(needed: Long, free: Long) {
                    _state.value = TransferState.Failed(TransferRole.RECEIVE, TransferFailure.NO_SPACE, free)
                    stopReceiverInternal()
                }
                override fun onTooManyAttempts() {
                    _state.value = TransferState.Failed(TransferRole.RECEIVE, TransferFailure.TOO_MANY_ATTEMPTS)
                    stopReceiverInternal()
                }
            })
            try {
                val port = r.start()
                receiver = r
                startResponder(port)
                _state.value = TransferState.Waiting(code)
            } catch (e: Exception) {
                fail(TransferRole.RECEIVE, TransferFailure.PORT_IN_USE)
            }
        }
    }

    /** Odgovaranje na upite pošiljatelja ("tko prima?"). Bez toga i dalje radi ručni unos IP adrese. */
    private fun startResponder(tcpPort: Int) {
        try {
            val socket = DatagramSocket(null as java.net.SocketAddress?).apply {
                reuseAddress = true
                broadcast = true
                soTimeout = 1000
                bind(InetSocketAddress(Discovery.PORT))
            }
            multicast = LocalNet.multicastLock(context)
            val name = (Build.MANUFACTURER + " " + Build.MODEL).trim()
            responder = Discovery.Responder(socket, tcpPort, name) { packet -> reply(socket, packet) }.also { it.start() }
        } catch (e: Exception) {
            // Port zauzet ili mreža nedostupna – pošiljatelj može upisati IP adresu.
        }
    }

    /**
     * Odgovor ide kroz soket vezan uz Wi-Fi kad je pošiljatelj u Wi-Fi mreži ovog mobitela
     * (inače bi ga Android mogao poslati mobilnom mrežom ako Wi-Fi nema internet).
     */
    private fun reply(listen: DatagramSocket, packet: DatagramPacket) {
        val net = LocalNet.wifiNetworkFor(context, packet.address)
        if (net == null) {
            listen.send(packet)
            return
        }
        val s = synchronized(replySockets) {
            replySockets.getOrPut(net) { DatagramSocket().also { net.bindSocket(it) } }
        }
        s.send(packet)
    }

    private fun stopReceiverInternal() {
        receiver?.stop(); receiver = null
        responder?.stop(); responder = null
        synchronized(replySockets) {
            replySockets.values.forEach { try { it.close() } catch (e: Exception) { } }
            replySockets.clear()
        }
        multicast?.let { try { if (it.isHeld) it.release() } catch (e: Exception) { } }
        multicast = null
    }

    /** Naziv podmape za svaku vrstu (prema jeziku aplikacije). */
    private fun folderName(c: TransferCategory): String = context.getString(
        when (c) {
            TransferCategory.PHOTOS -> R.string.tr_cat_photos
            TransferCategory.VIDEOS -> R.string.tr_cat_videos
            TransferCategory.AUDIO -> R.string.tr_cat_audio
            TransferCategory.DOCUMENTS -> R.string.tr_cat_documents
            TransferCategory.ARCHIVES -> R.string.tr_folder_archives
            TransferCategory.APK_FILES -> R.string.tr_folder_apk
            TransferCategory.APPS -> R.string.tr_cat_apps
            TransferCategory.OTHER -> R.string.tr_cat_other
        }
    )

    // ---------- Slanje ----------

    /**
     * Slanje. [manualHost] = IP adresa koju je korisnik upisao; null = automatsko traženje primatelja.
     */
    fun startSending(items: List<TransferItem>, codeInput: String, manualHost: String?) {
        if (_state.value.isBusy) return
        val code = PairingCode.normalize(codeInput) ?: run { _state.value = TransferState.Failed(TransferRole.SEND, TransferFailure.AUTH_FAILED); return }
        val manual = manualHost?.trim()?.takeIf { it.isNotEmpty() }
        if (manual != null && !LocalNet.isIpv4(manual)) {
            _state.value = TransferState.Failed(TransferRole.SEND, TransferFailure.BAD_ADDRESS); return
        }
        cancelled.set(false)
        lastCode = code
        _state.value = TransferState.Preparing(TransferRole.SEND, searching = manual == null)
        job = scope.launch {
            val prefs = features.currentTransfer()
            if (prefs.background) startService()
            precheck()?.let { fail(TransferRole.SEND, it); return@launch }
            val name = (Build.MANUFACTURER + " " + Build.MODEL).trim()
            val error = withReceiver(code, manual, name) { sender, host ->
                val result = sender.send(items, AndroidTransferSource(context), { cancelled.get() }) { p ->
                    _state.value = TransferState.Active(TransferRole.SEND, p, host)
                }
                lastHost = host
                _state.value = TransferState.Finished(TransferRole.SEND, result, emptyList())
            }
            finishWithError(error)
        }
    }

    /**
     * Test brzine mreže prema primatelju (primatelj mora biti na zaslonu Primi s istim kodom).
     * Šalje nule 8 sekundi preko istog broja veza kao pravi prijenos, bez čitanja i spremanja datoteka.
     */
    fun startSpeedTest(codeInput: String, manualHost: String?) {
        if (_state.value.isBusy) return
        val code = PairingCode.normalize(codeInput) ?: run { _state.value = TransferState.Failed(TransferRole.SEND, TransferFailure.AUTH_FAILED); return }
        val manual = manualHost?.trim()?.takeIf { it.isNotEmpty() }
        if (manual != null && !LocalNet.isIpv4(manual)) {
            _state.value = TransferState.Failed(TransferRole.SEND, TransferFailure.BAD_ADDRESS); return
        }
        cancelled.set(false)
        _state.value = TransferState.Preparing(TransferRole.SEND, searching = manual == null)
        job = scope.launch {
            precheck()?.let { fail(TransferRole.SEND, it); return@launch }
            val name = (Build.MANUFACTURER + " " + Build.MODEL).trim()
            val error = withReceiver(code, manual, name) { sender, host ->
                _state.value = TransferState.SpeedTest(0, running = true, peer = host)
                val bps = sender.speedTest(SPEED_TEST_MS, { cancelled.get() }) { live ->
                    _state.value = TransferState.SpeedTest(live, running = true, peer = host)
                }
                lastHost = host
                lastCode = code
                _state.value = TransferState.SpeedTest(bps, running = false, peer = host)
            }
            finishWithError(error)
        }
    }

    /**
     * Pronalazi primatelja (ručna adresa ili automatsko traženje) i izvršava [op]. Vraća null ako je uspjelo,
     * inače zadnju grešku. Svaka adresa dobiva do 3 pokušaja – nakon spajanja na žarišnu točku veza zna kasniti.
     */
    private suspend fun withReceiver(
        code: String,
        manual: String?,
        deviceName: String,
        op: (TransferSender, String) -> Unit
    ): TransferException? {
        val candidates: List<String> = if (manual != null) listOf(manual) else findReceivers()
        if (cancelled.get()) return null
        if (candidates.isEmpty()) return TransferException(TransferException.Reason.CONNECTION, cause = NotFound())
        _state.value = TransferState.Preparing(TransferRole.SEND)
        var lastError: TransferException? = null
        for (host in candidates) {
            if (cancelled.get()) break
            for (attempt in 0 until 3) {
                if (cancelled.get()) break
                try {
                    val net = LocalNet.wifiNetworkFor(context, InetAddress.getByName(host))
                    val sender = TransferSender(
                        host, PairingCode.PORT, code, deviceName = deviceName, streams = STREAMS,
                        socketFactory = { Socket().also { s -> net?.bindSocket(s) } }
                    )
                    op(sender, host)
                    return null
                } catch (e: TransferException) {
                    lastError = e
                    val started = _state.value is TransferState.Active || _state.value is TransferState.SpeedTest
                    if (e.reason != TransferException.Reason.CONNECTION || started) break
                    kotlinx.coroutines.delay(1200)
                } catch (e: Exception) {
                    lastError = TransferException(TransferException.Reason.CONNECTION, cause = e)
                    break
                }
            }
            // Krivi kod ili zauzet primatelj na jednoj adresi – možda je pravi primatelj na sljedećoj.
            if (_state.value is TransferState.Active || _state.value is TransferState.SpeedTest) break
        }
        return lastError ?: TransferException(TransferException.Reason.CONNECTION)
    }

    private class NotFound : Exception()

    private fun finishWithError(error: TransferException?) {
        if (error == null) {
            if (cancelled.get() && _state.value !is TransferState.Finished) _state.value = TransferState.Idle
            return
        }
        if (cancelled.get()) { _state.value = TransferState.Idle; return }
        val reason = when {
            error.cause is NotFound -> TransferFailure.NOT_FOUND
            error.reason == TransferException.Reason.AUTH_FAILED -> TransferFailure.AUTH_FAILED
            error.reason == TransferException.Reason.NO_SPACE -> TransferFailure.NO_SPACE
            error.reason == TransferException.Reason.BUSY -> TransferFailure.BUSY
            error.reason == TransferException.Reason.CANCELLED -> { _state.value = TransferState.Idle; return }
            else -> TransferFailure.CONNECT_FAILED
        }
        _state.value = TransferState.Failed(TransferRole.SEND, reason, error.freeBytes)
    }

    /** Automatsko traženje: odgovori primatelja na UDP upit, a ako ih nema – provjera porta u lokalnoj mreži. */
    private fun findReceivers(): List<String> {
        val result = LinkedHashSet<String>()
        repeat(2) {
            if (result.isNotEmpty() || cancelled.get()) return@repeat
            val targets = LocalNet.discoveryTargets(context, Discovery.PORT)
            try {
                Discovery.find(targets, timeoutMs = 3000).forEach { f -> f.address.hostAddress?.let { result += it } }
            } finally {
                targets.forEach { try { it.first.close() } catch (e: Exception) { } }
            }
        }
        // Rezerva: provjera porta na adresama u lokalnoj mreži (npr. kad uređaj blokira UDP upite).
        if (result.isEmpty() && !cancelled.get()) result += LocalNet.sweep(context, PairingCode.PORT) { cancelled.get() }
        return result.toList()
    }

    /** Ponovno slanje neuspjelih stavki zadnjeg slanja (istom primatelju, istim kodom). */
    fun retryFailed() {
        val s = _state.value as? TransferState.Finished ?: return
        if (s.role != TransferRole.SEND) return
        val items = s.result.failed.map { it.first }
        val code = lastCode ?: return
        if (items.isEmpty()) return
        startSending(items, code, lastHost)
    }

    // ---------- Zajedničko ----------

    private fun fail(role: TransferRole, reason: TransferFailure) {
        stopReceiverInternal()
        _state.value = TransferState.Failed(role, reason)
    }

    /** Otkazivanje (pošiljatelj prekida slanje, primatelj prestaje čekati/primati). */
    fun cancel() {
        cancelled.set(true)
        val s = _state.value
        if (s is TransferState.SpeedTest) return // test sam završava (provjerava zastavicu)
        if (s is TransferState.Waiting || s is TransferState.Preparing || (s is TransferState.Active && s.role == TransferRole.RECEIVE) ||
            (s is TransferState.Finished && s.listeningCode != null)
        ) {
            job?.cancel()
            stopReceiverInternal()
            _state.value = TransferState.Idle
        }
    }

    /** Povratak na početni zaslon nakon završetka ili pogreške ("Gotovo" – primatelj prestaje primati). */
    fun reset() {
        if (_state.value.isBusy) return
        stopReceiverInternal()
        _state.value = TransferState.Idle
    }

    private fun startService() {
        try {
            ContextCompat.startForegroundService(context, Intent(context, TransferService::class.java))
        } catch (e: Exception) {
            // Npr. ograničenje pokretanja usluga – prijenos radi dok je aplikacija otvorena.
        }
    }

    companion object {
        /** Broj paralelnih TCP veza – 4 daju najbolji omjer brzine i opterećenja na Wi-Fi vezi. */
        const val STREAMS = 4
        const val SPEED_TEST_MS = 10_000L
    }
}

package hr.smartduplicatecleaner.storage

import android.content.ContentUris
import android.content.Context
import android.database.Cursor
import android.net.Uri
import android.os.Environment
import android.os.storage.StorageManager
import android.provider.DocumentsContract
import android.provider.MediaStore
import hr.smartduplicatecleaner.core.logic.FileClassifier
import hr.smartduplicatecleaner.core.model.DateSource
import hr.smartduplicatecleaner.core.model.FileCategory
import hr.smartduplicatecleaner.core.model.ScannedFile
import hr.smartduplicatecleaner.core.model.SourceType
import hr.smartduplicatecleaner.core.scan.CancelToken
import hr.smartduplicatecleaner.core.scan.FileSource
import hr.smartduplicatecleaner.core.scan.SourceWarning
import hr.smartduplicatecleaner.core.scan.WarningKind
import java.io.File
import java.nio.file.Files
import java.util.Locale

/**
 * Izvor 1: MediaStore – fotografije, videozapisi i audiozapisi na svim vanjskim volumenima
 * (interna memorija i SD kartica). Ne vidi dokumente drugih aplikacija (ograničenje Androida 11+).
 */
class MediaStoreSource(
    private val context: Context,
    private val categories: Set<FileCategory>
) : FileSource {
    override val id: String = "mediastore"

    override fun enumerate(cancel: CancelToken, emit: (ScannedFile) -> Unit, warn: (SourceWarning) -> Unit) {
        val wanted = mutableListOf<Pair<FileCategory, MediaAccess>>()
        if (FileCategory.IMAGE in categories) wanted += FileCategory.IMAGE to StorageAccess.imagesAccess(context)
        if (FileCategory.VIDEO in categories) wanted += FileCategory.VIDEO to StorageAccess.videoAccess(context)
        if (FileCategory.AUDIO in categories) wanted += FileCategory.AUDIO to StorageAccess.audioAccess(context)
        if (wanted.isEmpty()) return

        if (wanted.all { it.second == MediaAccess.NONE }) throw SecurityException("media")
        for ((category, access) in wanted) {
            when (access) {
                MediaAccess.NONE -> warn(SourceWarning("mediastore:${category.name}", WarningKind.PERMISSION_DENIED))
                MediaAccess.PARTIAL -> warn(SourceWarning("mediastore:${category.name}", WarningKind.PARTIAL_ACCESS))
                MediaAccess.FULL -> Unit
            }
        }
        if (!StorageAccess.hasMediaLocation(context) && wanted.any { it.first != FileCategory.AUDIO && it.second != MediaAccess.NONE }) {
            warn(SourceWarning("mediastore", WarningKind.PARTIAL_ACCESS, "media_location"))
        }

        val volumes = MediaStore.getExternalVolumeNames(context)
        for (volume in volumes) {
            for ((category, access) in wanted) {
                if (access == MediaAccess.NONE) continue
                cancel.throwIfCancelled()
                val collection = when (category) {
                    FileCategory.IMAGE -> MediaStore.Images.Media.getContentUri(volume)
                    FileCategory.VIDEO -> MediaStore.Video.Media.getContentUri(volume)
                    else -> MediaStore.Audio.Media.getContentUri(volume)
                }
                try {
                    query(collection, volume, category, cancel, emit)
                } catch (e: SecurityException) {
                    throw e
                } catch (e: Exception) {
                    warn(SourceWarning("mediastore:$volume", WarningKind.INACCESSIBLE, e.message))
                }
            }
        }
    }

    private fun query(collection: Uri, volume: String, category: FileCategory, cancel: CancelToken, emit: (ScannedFile) -> Unit) {
        val projection = arrayOf(
            MediaStore.MediaColumns._ID,
            MediaStore.MediaColumns.DISPLAY_NAME,
            MediaStore.MediaColumns.RELATIVE_PATH,
            MediaStore.MediaColumns.SIZE,
            MediaStore.MediaColumns.MIME_TYPE,
            MediaStore.MediaColumns.DATE_ADDED,
            MediaStore.MediaColumns.DATE_MODIFIED,
            MediaStore.MediaColumns.DATE_TAKEN,
            MediaStore.MediaColumns.WIDTH,
            MediaStore.MediaColumns.HEIGHT
        )
        context.contentResolver.query(collection, projection, null, null, null)?.use { c ->
            val iId = c.getColumnIndexOrThrow(MediaStore.MediaColumns._ID)
            val iName = c.getColumnIndexOrThrow(MediaStore.MediaColumns.DISPLAY_NAME)
            val iPath = c.getColumnIndex(MediaStore.MediaColumns.RELATIVE_PATH)
            val iSize = c.getColumnIndexOrThrow(MediaStore.MediaColumns.SIZE)
            val iMime = c.getColumnIndex(MediaStore.MediaColumns.MIME_TYPE)
            val iAdded = c.getColumnIndex(MediaStore.MediaColumns.DATE_ADDED)
            val iModified = c.getColumnIndex(MediaStore.MediaColumns.DATE_MODIFIED)
            val iTaken = c.getColumnIndex(MediaStore.MediaColumns.DATE_TAKEN)
            val iW = c.getColumnIndex(MediaStore.MediaColumns.WIDTH)
            val iH = c.getColumnIndex(MediaStore.MediaColumns.HEIGHT)
            while (c.moveToNext()) {
                cancel.throwIfCancelled()
                val name = c.getString(iName) ?: continue
                val dir = StorageAccess.normalizeDir(c.stringOrNull(iPath).orEmpty())
                if (StorageAccess.isProtectedDir(dir)) continue
                val id = c.getLong(iId)
                val mime = c.stringOrNull(iMime)
                val taken = c.longOrNull(iTaken)?.takeIf { it > 0 }
                emit(
                    ScannedFile(
                        key = StorageAccess.canonicalKey(volume, dir, name),
                        uri = ContentUris.withAppendedId(collection, id).toString(),
                        source = SourceType.MEDIA_STORE,
                        name = name,
                        volume = volume,
                        relativeDir = dir,
                        sizeBytes = c.getLong(iSize),
                        mimeType = mime,
                        category = category,
                        // Datum snimanja iz MediaStorea (za video i za vremenski filtar). Za fotografije se kasnije,
                        // za članove grupa, zamjenjuje datumom izravno iz EXIF-a (pouzdanije).
                        dateTakenMillis = if (category != FileCategory.AUDIO) taken else null,
                        dateTakenSource = if (category != FileCategory.AUDIO && taken != null) DateSource.MEDIA_METADATA else null,
                        dateAddedMillis = c.longOrNull(iAdded)?.takeIf { it > 0 }?.times(1000),
                        dateModifiedMillis = c.longOrNull(iModified)?.takeIf { it > 0 }?.times(1000),
                        width = c.intOrNull(iW)?.takeIf { it > 0 },
                        height = c.intOrNull(iH)?.takeIf { it > 0 }
                    )
                )
            }
        }
    }
}

/**
 * Izvor 2: mapa koju je korisnik odobrio preko Storage Access Frameworka (ACTION_OPEN_DOCUMENT_TREE).
 * Omogućuje skeniranje dokumenata i arhiva bez dopuštenja za pristup svim datotekama.
 */
class SafTreeSource(
    private val context: Context,
    private val treeUri: String
) : FileSource {
    override val id: String = "saf:" + StorageAccess.treeDisplayName(treeUri)

    override fun enumerate(cancel: CancelToken, emit: (ScannedFile) -> Unit, warn: (SourceWarning) -> Unit) {
        val tree = Uri.parse(treeUri)
        val hasPermission = context.contentResolver.persistedUriPermissions.any { it.uri == tree && it.isReadPermission }
        if (!hasPermission) throw SecurityException("tree")
        val rootId = DocumentsContract.getTreeDocumentId(tree)
        val isExternalStorage = tree.authority == EXTERNAL_STORAGE_AUTHORITY
        val stack = ArrayDeque<String>()
        stack.add(rootId)
        val projection = arrayOf(
            DocumentsContract.Document.COLUMN_DOCUMENT_ID,
            DocumentsContract.Document.COLUMN_DISPLAY_NAME,
            DocumentsContract.Document.COLUMN_MIME_TYPE,
            DocumentsContract.Document.COLUMN_SIZE,
            DocumentsContract.Document.COLUMN_LAST_MODIFIED
        )
        while (stack.isNotEmpty()) {
            cancel.throwIfCancelled()
            val parentId = stack.removeLast()
            val children = DocumentsContract.buildChildDocumentsUriUsingTree(tree, parentId)
            val cursor = try {
                context.contentResolver.query(children, projection, null, null, null)
            } catch (e: SecurityException) {
                throw e
            } catch (e: Exception) {
                warn(SourceWarning(id, WarningKind.INACCESSIBLE, e.message)); null
            } ?: continue
            cursor.use { c ->
                while (c.moveToNext()) {
                    cancel.throwIfCancelled()
                    val docId = c.getString(0) ?: continue
                    val name = c.getString(1) ?: continue
                    val mime = c.stringOrNull(2)
                    if (mime == DocumentsContract.Document.MIME_TYPE_DIR) {
                        if (!name.startsWith(".")) stack.add(docId)
                        continue
                    }
                    val docUri = DocumentsContract.buildDocumentUriUsingTree(tree, docId)
                    var volume: String? = null
                    var dir = ""
                    var key = "saf:" + docUri.toString()
                    if (isExternalStorage && docId.contains(':')) {
                        volume = StorageAccess.volumeFromSafRoot(docId.substringBefore(':'))
                        val path = docId.substringAfter(':')
                        dir = StorageAccess.normalizeDir(path.substringBeforeLast('/', ""))
                        key = StorageAccess.canonicalKey(volume, dir, name)
                    }
                    if (StorageAccess.isProtectedDir(dir)) continue
                    emit(
                        ScannedFile(
                            key = key,
                            uri = docUri.toString(),
                            source = SourceType.SAF_TREE,
                            name = name,
                            volume = volume,
                            relativeDir = dir,
                            sizeBytes = c.longOrNull(3) ?: 0L,
                            mimeType = mime,
                            category = FileClassifier.classify(name, mime),
                            dateModifiedMillis = c.longOrNull(4)?.takeIf { it > 0 },
                            treeUri = treeUri,
                            documentId = docId
                        )
                    )
                }
            }
        }
    }

    companion object {
        const val EXTERNAL_STORAGE_AUTHORITY = "com.android.externalstorage.documents"
    }
}

/**
 * Izvor 3: izravno čitanje datotečnog sustava – samo uz odobreno "Pristup svim datotekama".
 * Pronalazi i dokumente, arhive i ostale datoteke na internoj memoriji i SD kartici.
 * Preskače Android/data, Android/obb, skrivene mape (".") i mapu za oporavak.
 */
class FileSystemSource(private val context: Context) : FileSource {
    override val id: String = "filesystem"

    override fun enumerate(cancel: CancelToken, emit: (ScannedFile) -> Unit, warn: (SourceWarning) -> Unit) {
        if (!StorageAccess.hasAllFilesAccess()) throw SecurityException("all_files")
        for ((root, volume) in volumes()) {
            cancel.throwIfCancelled()
            if (!root.canRead()) {
                warn(SourceWarning("filesystem:$volume", WarningKind.INACCESSIBLE)); continue
            }
            val stack = ArrayDeque<File>()
            stack.add(root)
            while (stack.isNotEmpty()) {
                cancel.throwIfCancelled()
                val dir = stack.removeLast()
                val entries = dir.listFiles() ?: continue
                for (f in entries) {
                    cancel.throwIfCancelled()
                    val rel = f.absolutePath.removePrefix(root.absolutePath).trimStart('/')
                    if (f.isDirectory) {
                        if (f.name.startsWith(".")) continue
                        if (StorageAccess.isProtectedDir(rel + "/")) continue
                        if (Files.isSymbolicLink(f.toPath())) continue
                        stack.add(f)
                        continue
                    }
                    val relDir = StorageAccess.normalizeDir(rel.substringBeforeLast('/', ""))
                    if (StorageAccess.isProtectedDir(relDir)) continue
                    emit(
                        ScannedFile(
                            key = StorageAccess.canonicalKey(volume, relDir, f.name),
                            uri = Uri.fromFile(f).toString(),
                            source = SourceType.FILE_SYSTEM,
                            name = f.name,
                            volume = volume,
                            relativeDir = relDir,
                            sizeBytes = f.length(),
                            mimeType = null,
                            category = FileClassifier.classify(f.name, null),
                            dateModifiedMillis = f.lastModified().takeIf { it > 0 },
                            absolutePath = f.absolutePath
                        )
                    )
                }
            }
        }
    }

    /** Montirani volumeni: (korijenska mapa, MediaStore naziv volumena). */
    private fun volumes(): List<Pair<File, String>> {
        val sm = context.getSystemService(StorageManager::class.java)
        return sm.storageVolumes.mapNotNull { v ->
            val dir = v.directory ?: return@mapNotNull null
            if (v.state != Environment.MEDIA_MOUNTED && v.state != Environment.MEDIA_MOUNTED_READ_ONLY) return@mapNotNull null
            val name = if (v.isPrimary) "external_primary" else (v.uuid ?: return@mapNotNull null).lowercase(Locale.ROOT)
            dir to name
        }
    }
}

/** Popis medijskih mapa za izbornik mapa (prve dvije razine putanje). */
fun listMediaFolders(context: Context): List<String> {
    val result = sortedSetOf<String>(String.CASE_INSENSITIVE_ORDER)
    val collections = listOf(
        MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
        MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
        MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
    )
    for (uri in collections) {
        try {
            context.contentResolver.query(uri, arrayOf(MediaStore.MediaColumns.RELATIVE_PATH), null, null, null)?.use { c ->
                while (c.moveToNext()) {
                    val path = c.getString(0) ?: continue
                    val parts = path.trim('/').split('/').filter { it.isNotEmpty() }
                    if (parts.isEmpty()) continue
                    result += parts.take(2).joinToString("/") + "/"
                    result += parts.first() + "/"
                }
            }
        } catch (e: Exception) {
            // Bez dopuštenja popis je prazan; korisnik može dodati mapu preko SAF-a.
        }
    }
    return result.toList()
}

private fun Cursor.stringOrNull(i: Int): String? = if (i < 0 || isNull(i)) null else getString(i)
private fun Cursor.longOrNull(i: Int): Long? = if (i < 0 || isNull(i)) null else getLong(i)
private fun Cursor.intOrNull(i: Int): Int? = if (i < 0 || isNull(i)) null else getInt(i)

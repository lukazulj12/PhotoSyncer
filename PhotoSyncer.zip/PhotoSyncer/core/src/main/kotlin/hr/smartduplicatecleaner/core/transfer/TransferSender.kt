package hr.smartduplicatecleaner.core.transfer

import hr.smartduplicatecleaner.core.scan.CancelToken
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.Closeable
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.InputStream
import java.net.InetSocketAddress
import java.net.Socket
import java.util.Collections
import java.util.concurrent.ConcurrentLinkedQueue
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong

/**
 * Pošiljatelj. Otvara kontrolnu vezu (provjera koda, popis datoteka, provjera prostora na primatelju),
 * zatim [streams] paralelnih podatkovnih veza – više istovremenih TCP veza bolje iskorištava Wi-Fi
 * i ubrzava prijenos mnogo malih datoteka. Velike datoteke šalju se prve radi ravnomjernog opterećenja.
 */
class TransferSender(
    private val host: String,
    private val port: Int,
    code: String,
    private val deviceName: String = "",
    private val streams: Int = 4,
    private val connectTimeoutMs: Int = 10_000,
    private val socketFactory: () -> Socket = { Socket() }
) {
    private val key = PairingCode.authKey(code)

    private class Conn(val socket: Socket) : Closeable {
        val inp = DataInputStream(BufferedInputStream(socket.getInputStream(), 64 * 1024))
        val out = DataOutputStream(BufferedOutputStream(socket.getOutputStream(), Proto.BUFFER))
        override fun close() { try { socket.close() } catch (e: Exception) { } }
    }

    private class Stop : RuntimeException()

    fun send(
        items: List<TransferItem>,
        source: TransferSource,
        cancel: CancelToken = CancelToken.NONE,
        onProgress: (TransferProgress) -> Unit = {}
    ): TransferResult {
        val started = System.currentTimeMillis()
        val control = connect(Proto.TYPE_CONTROL)
        try {
            control.out.writeUTF(deviceName.take(60))
            control.out.writeInt(items.size)
            items.forEach { Proto.writeItem(control.out, it) }
            control.out.flush()

            val status = control.inp.readUnsignedByte()
            val free = control.inp.readLong()
            if (status == Proto.NO_SPACE) throw TransferException(TransferException.Reason.NO_SPACE, free)
            if (status != Proto.OK) throw TransferException(TransferException.Reason.PROTOCOL)
            val skipIds = HashSet<Int>()
            repeat(control.inp.readInt()) { skipIds += control.inp.readInt() }

            val skipped = items.filter { it.id in skipIds }
            val toSend = items.filter { it.id !in skipIds }.sortedByDescending { it.size }
            val total = toSend.sumOf { it.size }
            val queue = ConcurrentLinkedQueue(toSend)
            val ok = Collections.synchronizedList(mutableListOf<TransferItem>())
            val failed = Collections.synchronizedList(mutableListOf<Pair<TransferItem, String>>())
            val bytes = AtomicLong()
            val done = AtomicInteger()
            val lastEmit = AtomicLong()

            fun progress(force: Boolean = false) {
                val now = System.currentTimeMillis()
                val last = lastEmit.get()
                if (force || now - last >= 200 && lastEmit.compareAndSet(last, now)) {
                    onProgress(TransferProgress(done.get(), toSend.size, bytes.get(), total, failed.size, started))
                }
            }
            progress(force = true)

            val workers = (0 until streams.coerceIn(1, 8).coerceAtMost(maxOf(1, toSend.size))).map {
                Thread({
                    runStream(queue, source, cancel, ok, failed, done) { n -> bytes.addAndGet(n.toLong()); progress() }
                    progress()
                }, "photosync-send-$it").apply { start() }
            }
            workers.forEach { it.join() }

            // Što je ostalo u redu (sve veze prekinute ili otkazano) – neuspjelo.
            val cancelled = cancel.isCancelled()
            while (true) {
                val item = queue.poll() ?: break
                failed += item to (if (cancelled) "cancelled" else "connection")
                done.incrementAndGet()
            }
            progress(force = true)

            // Pri otkazivanju se DONE ne šalje – primatelj tada sesiju bilježi kao prekinutu.
            if (!cancelled) try {
                control.out.writeByte(Proto.DONE)
                control.out.flush()
                control.inp.readInt(); control.inp.readInt()
            } catch (e: Exception) {
                // Sažetak primatelja je samo potvrda; rezultat se temelji na potvrdama za svaku datoteku.
            }
            return TransferResult(ok.toList(), failed.toList(), skipped, bytes.get(), System.currentTimeMillis() - started, cancelled)
        } catch (e: TransferException) {
            throw e
        } catch (e: Exception) {
            throw TransferException(if (cancel.isCancelled()) TransferException.Reason.CANCELLED else TransferException.Reason.CONNECTION, cause = e)
        } finally {
            control.close()
        }
    }

    /**
     * Jedna podatkovna veza: pisač šalje datoteke jednu za drugom bez čekanja, a čitač usporedno prima potvrde
     * (id + uspjeh). Najviše [Proto.MAX_IN_FLIGHT] nepotvrđenih datoteka po vezi. Ako se veza prekine,
     * sve nepotvrđene datoteke bilježe se kao neuspjele ("connection").
     */
    private fun runStream(
        queue: ConcurrentLinkedQueue<TransferItem>,
        source: TransferSource,
        cancel: CancelToken,
        ok: MutableList<TransferItem>,
        failed: MutableList<Pair<TransferItem, String>>,
        done: AtomicInteger,
        counted: (Int) -> Unit
    ) {
        val inFlight = java.util.concurrent.ConcurrentHashMap<Int, Pair<TransferItem, String?>>()
        val slots = java.util.concurrent.Semaphore(Proto.MAX_IN_FLIGHT)
        val broken = java.util.concurrent.atomic.AtomicBoolean(false)
        val conn = try { connect(Proto.TYPE_DATA) } catch (e: Exception) { return }
        val reader = Thread({
            try {
                while (true) {
                    val id = conn.inp.readInt()
                    if (id == Proto.END) break
                    val status = conn.inp.readUnsignedByte()
                    val entry = inFlight.remove(id) ?: continue
                    val error = entry.second ?: if (status == 0) null else "receiver"
                    if (error == null) ok += entry.first else failed += entry.first to error
                    done.incrementAndGet()
                    slots.release()
                }
            } catch (e: Exception) {
                broken.set(true)
                conn.close()
            } finally {
                slots.release(Proto.MAX_IN_FLIGHT) // pisač ne smije ostati blokiran
            }
        }, "photosync-acks").apply { isDaemon = true; start() }

        val buf = ByteArray(Proto.BUFFER)
        try {
            while (!cancel.isCancelled() && !broken.get()) {
                val item = queue.poll() ?: break
                while (!slots.tryAcquire(200, java.util.concurrent.TimeUnit.MILLISECONDS)) {
                    if (broken.get() || cancel.isCancelled()) break
                }
                if (broken.get() || cancel.isCancelled()) { queue.add(item); break }
                inFlight[item.id] = item to null
                // Greška izvora bilježi se prije završnog bajta – potvrda primatelja može stići odmah nakon njega.
                sendOne(conn, item, source, buf, cancel, counted) { err -> inFlight[item.id] = item to err }
            }
            if (!broken.get() && !cancel.isCancelled()) {
                conn.out.writeInt(Proto.END)
                conn.out.flush()
                reader.join() // čeka potvrde za sve poslane datoteke
            }
        } catch (e: Exception) {
            broken.set(true)
        } finally {
            conn.close()
            reader.join(5_000)
            // Nepotvrđene datoteke (prekid veze ili otkazivanje).
            val reason = if (cancel.isCancelled()) "cancelled" else "connection"
            for (id in inFlight.keys.toList()) {
                inFlight.remove(id)?.let { failed += it.first to reason; done.incrementAndGet() }
            }
        }
    }

    /** Šalje jednu datoteku (zaglavlje, sadržaj, završni bajt). @return null ili razlog greške izvora */
    private fun sendOne(
        conn: Conn, item: TransferItem, source: TransferSource, buf: ByteArray, cancel: CancelToken,
        counted: (Int) -> Unit, onSourceError: (String) -> Unit
    ): String? {
        val out = conn.out
        out.writeInt(item.id)
        out.writeLong(item.size)
        var sent = 0L
        var sourceError: String? = null
        var input: InputStream? = try { source.open(item) } catch (e: Exception) { sourceError = "open: " + (e.message ?: e.javaClass.simpleName); null }
        try {
            while (sent < item.size) {
                if (cancel.isCancelled()) throw Stop()
                val want = minOf(buf.size.toLong(), item.size - sent).toInt()
                val n = if (input == null) -1 else try {
                    input.read(buf, 0, want)
                } catch (e: Exception) {
                    sourceError = "read: " + (e.message ?: e.javaClass.simpleName); -1
                }
                if (n < 0) break
                if (n == 0) continue
                out.write(buf, 0, n)
                sent += n
                counted(n)
            }
        } finally {
            try { input?.close() } catch (e: Exception) { }
            input = null
        }
        if (sent < item.size) {
            // Izvor je kraći ili nedostupan – popuna nulama da veza ostane usklađena; primatelj odbacuje datoteku.
            if (sourceError == null) sourceError = "short"
            java.util.Arrays.fill(buf, 0.toByte())
            while (sent < item.size) {
                if (cancel.isCancelled()) throw Stop()
                val n = minOf(buf.size.toLong(), item.size - sent).toInt()
                out.write(buf, 0, n)
                sent += n
            }
        }
        sourceError?.let(onSourceError)
        out.writeByte(if (sourceError == null) 0 else 1)
        // Bez čekanja potvrde; flush samo da zadnja datoteka ne ostane u međuspremniku.
        out.flush()
        return sourceError
    }

    /**
     * Test brzine mreže: [streams] veza šalje nule [durationMs] milisekundi, a primatelj ih broji bez spremanja i
     * redovito javlja koliko je stvarno primio. [onProgress] dobiva trenutačnu brzinu (B/s, zadnjih ~1,5 s).
     *
     * Rezultat je prosjek nakon zagrijavanja ([warmupMs]): u prvim trenucima mobitel puni međuspremnike i
     * Wi-Fi izlazi iz štednog načina, pa bi brzina "poslanog" bila lažno visoka, a "primljenog" lažno niska.
     * @return prosječna stvarno primljena brzina u bajtovima po sekundi
     */
    fun speedTest(
        durationMs: Long = 10_000,
        cancel: CancelToken = CancelToken.NONE,
        warmupMs: Long = minOf(2_000L, durationMs / 4),
        onProgress: (Long) -> Unit = {}
    ): Long {
        val conns = ArrayList<Conn>()
        try {
            repeat(streams.coerceIn(1, 8)) { conns += connect(Proto.TYPE_SPEED) }
        } catch (e: Exception) {
            conns.forEach { it.close() }
            throw e
        }
        val totals = java.util.concurrent.atomic.AtomicLongArray(conns.size)
        val finals = java.util.concurrent.atomic.AtomicInteger()
        val started = System.currentTimeMillis()
        val end = started + durationMs
        val threads = conns.mapIndexed { i, conn ->
            val reader = Thread({
                try {
                    while (true) {
                        val v = conn.inp.readLong()
                        if (v == -1L) { totals.set(i, conn.inp.readLong()); finals.incrementAndGet(); break }
                        totals.set(i, v)
                    }
                } catch (e: Exception) {
                }
            }, "photosync-speed-r").apply { isDaemon = true; start() }
            val writer = Thread({
                val buf = ByteArray(Proto.BUFFER)
                try {
                    while (System.currentTimeMillis() < end && !cancel.isCancelled()) conn.out.write(buf)
                    conn.out.flush()
                    conn.socket.shutdownOutput()
                } catch (e: Exception) {
                }
            }, "photosync-speed-w").apply { start() }
            reader to writer
        }
        fun sum(): Long { var t = 0L; for (k in 0 until totals.length()) t += totals.get(k); return t }
        // Uzorci (vrijeme, primljeno) za trenutačnu brzinu i za prosjek nakon zagrijavanja.
        val samples = ArrayList<Pair<Long, Long>>()
        var warmBytes = -1L
        var warmAt = 0L
        while (threads.any { it.first.isAlive } && System.currentTimeMillis() < end + 15_000) {
            Thread.sleep(250)
            val now = System.currentTimeMillis()
            val total = sum()
            samples += now to total
            if (warmBytes < 0 && now - started >= warmupMs) { warmBytes = total; warmAt = now }
            val ref = samples.lastOrNull { now - it.first >= 1_500 } ?: samples.first()
            val dt = (now - ref.first).coerceAtLeast(1)
            if (now - started >= 500) onProgress((total - ref.second) * 1000 / dt)
        }
        val finishedAt = System.currentTimeMillis()
        threads.forEach { (r, w) -> w.join(2_000); r.join(2_000) }
        conns.forEach { it.close() }
        if (cancel.isCancelled()) throw TransferException(TransferException.Reason.CANCELLED)
        val total = sum()
        if (total == 0L) throw TransferException(TransferException.Reason.CONNECTION)
        return if (warmBytes >= 0 && finishedAt - warmAt >= 500) (total - warmBytes) * 1000 / (finishedAt - warmAt)
        else total * 1000 / (finishedAt - started).coerceAtLeast(1)
    }

    private fun connect(type: Int): Conn {
        val socket = socketFactory()
        try {
            socket.tcpNoDelay = true
            // Veličinu međuspremnika ne postavljamo – automatsko prilagođavanje sustava daje veću brzinu.
            socket.connect(InetSocketAddress(host, port), connectTimeoutMs)
            socket.soTimeout = 120_000
        } catch (e: Exception) {
            try { socket.close() } catch (x: Exception) { }
            throw TransferException(TransferException.Reason.CONNECTION, cause = e)
        }
        val conn = Conn(socket)
        try {
            conn.out.write(Proto.MAGIC)
            conn.out.writeByte(type)
            conn.out.flush()
            val nonce = ByteArray(16)
            conn.inp.readFully(nonce)
            conn.out.write(Proto.hmac(key, Proto.label(type), nonce))
            conn.out.flush()
            when (conn.inp.readUnsignedByte()) {
                Proto.OK -> Unit
                Proto.AUTH_FAIL -> throw TransferException(TransferException.Reason.AUTH_FAILED)
                Proto.BUSY -> throw TransferException(TransferException.Reason.BUSY)
                else -> throw TransferException(TransferException.Reason.PROTOCOL)
            }
            if (type != Proto.TYPE_DATA) socket.soTimeout = 0 // kontrola čeka kraj prijenosa; test brzine čeka zbroj
            return conn
        } catch (e: TransferException) {
            conn.close(); throw e
        } catch (e: Exception) {
            conn.close(); throw TransferException(TransferException.Reason.CONNECTION, cause = e)
        }
    }
}

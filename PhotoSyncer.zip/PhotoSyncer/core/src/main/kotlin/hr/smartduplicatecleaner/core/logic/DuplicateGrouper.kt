package hr.smartduplicatecleaner.core.logic

import hr.smartduplicatecleaner.core.hash.PerceptualHash
import hr.smartduplicatecleaner.core.model.DuplicateGroup
import hr.smartduplicatecleaner.core.model.FileCategory
import hr.smartduplicatecleaner.core.model.GroupMember
import hr.smartduplicatecleaner.core.model.GroupType
import hr.smartduplicatecleaner.core.model.ScanSettings
import hr.smartduplicatecleaner.core.model.ScannedFile
import hr.smartduplicatecleaner.core.scan.CancelToken
import java.security.MessageDigest
import java.util.Locale

/**
 * Grupiranje datoteka u grupe duplikata.
 *
 * Grupe EXACT i VISUAL međusobno su disjunktne (datoteka pripada najviše jednoj), jer samo
 * one dobivaju automatski prijedlog – tako se izbjegava da dvije grupe proturječnim
 * prijedlozima označe sve kopije istog sadržaja. Grupe SIMILAR i SAME_NAME su savjetodavne,
 * mogu se preklapati s ostalima i nikad se ne označavaju automatski.
 */
object DuplicateGrouper {

    fun group(files: List<ScannedFile>, settings: ScanSettings, cancel: CancelToken = CancelToken.NONE): List<DuplicateGroup> {
        val result = mutableListOf<DuplicateGroup>()

        // 1) Sadržaji: datoteke s istim SHA-256 čine jedan "sadržaj".
        val contents: List<Content> = buildContents(files)
        val contentOf = HashMap<String, Content>()
        contents.forEach { c -> c.files.forEach { contentOf[it.key] = c } }

        // 2) Vizualni duplikati i slične fotografije (samo slike s perceptualnim hashom).
        // Vizualna usporedba (ista fotografija u drugoj datoteci, slične fotografije) samo ako je uključena u postavkama.
        // Isključeno = traže se isključivo potpuno identične datoteke (SHA-256).
        val imageContents = if (!settings.findSimilarPhotos) emptyList()
        else contents.filter { it.rep.category == FileCategory.IMAGE && it.rep.pHash != null }
        val usedInVisual = HashSet<Content>()
        val visualClusters = cluster(imageContents, ScanSettings.VISUAL_MAX_DISTANCE, strict = true, cancel = cancel)
        for (cluster in visualClusters) {
            if (cluster.contents.size < 2) continue
            usedInVisual += cluster.contents
            result += makeGroup(GroupType.VISUAL, FileCategory.IMAGE, cluster.contents, cluster.maxDistance)
        }

        // 3) Potpuno identične datoteke koje nisu već obuhvaćene vizualnom grupom.
        for (c in contents) {
            cancel.throwIfCancelled()
            if (c.files.size >= 2 && c.sha256 != null && c !in usedInVisual) {
                result += makeGroup(GroupType.EXACT, c.rep.category, listOf(c), null)
            }
        }

        // 4) Slične fotografije (savjetodavno) – samo sadržaji koji nisu u vizualnoj grupi.
        if (settings.findSimilarPhotos) {
            val remaining = imageContents.filter { it !in usedInVisual }
            val similar = cluster(remaining, settings.similarMaxDistance, strict = false, cancel = cancel)
            for (cluster in similar) {
                if (cluster.contents.size < 2) continue
                result += makeGroup(GroupType.SIMILAR, FileCategory.IMAGE, cluster.contents, cluster.maxDistance)
            }
        }

        // 5) Isti naziv, različit sadržaj (savjetodavno).
        val byName = files.groupBy { it.name.lowercase(Locale.ROOT) }
        for ((_, sameName) in byName) {
            cancel.throwIfCancelled()
            if (sameName.size < 2) continue
            val distinct = sameName.map { contentOf.getValue(it.key) }.distinct()
            if (distinct.size < 2) continue // svi identični → već su u EXACT/VISUAL grupi
            val members = sameName.map { f -> GroupMember(f.key, distinct.indexOf(contentOf.getValue(f.key))) }
            result += DuplicateGroup(groupId(GroupType.SAME_NAME, members), GroupType.SAME_NAME, sameName.first().category, members)
        }

        return result.sortedWith(compareBy<DuplicateGroup>({ it.type.ordinal }, { it.id }))
    }

    /** Sadržaj = skup datoteka s istim SHA-256 (ili jedna datoteka bez hasha). */
    private class Content(val files: List<ScannedFile>, val sha256: String?) {
        /** Predstavnik sadržaja – onaj s najvećom rezolucijom. */
        val rep: ScannedFile = files.maxWith(compareBy<ScannedFile> { it.pixelCount ?: 0L }.thenBy { it.key })
    }

    private fun buildContents(files: List<ScannedFile>): List<Content> {
        val withHash = files.filter { it.sha256 != null }.groupBy { it.sha256!! }
            .map { (sha, list) -> Content(list.sortedBy { it.key }, sha) }
        val withoutHash = files.filter { it.sha256 == null }.map { Content(listOf(it), null) }
        return (withHash + withoutHash).sortedBy { it.rep.key }
    }

    private class Cluster(val leader: Content) {
        val contents = mutableListOf(leader)
        var maxDistance = 0
    }

    /**
     * "Leader" klasteriranje uz BK-stablo: svaki sadržaj se pridružuje najbližem vođi
     * unutar praga. Za razliku od tranzitivnog spajanja, ovdje nema lančanja (A~B~C ≠ A~C).
     */
    private fun cluster(items: List<Content>, maxDistance: Int, strict: Boolean, cancel: CancelToken): List<Cluster> {
        // Vođe su sadržaji najveće rezolucije – najkvalitetnija verzija postaje referenca.
        val ordered = items.sortedWith(compareByDescending<Content> { it.rep.pixelCount ?: 0L }.thenBy { it.rep.key })
        val tree = BkTree()
        val clusters = mutableListOf<Cluster>()
        for (content in ordered) {
            cancel.throwIfCancelled()
            val ph = content.rep.pHash!!
            val match = tree.search(ph, maxDistance)
                .map { (idx, d) -> clusters[idx] to d }
                .filter { (cl, _) -> !strict || visuallySame(cl.leader.rep, content.rep) }
                .minWithOrNull(compareBy<Pair<Cluster, Int>> { it.second }.thenBy { it.first.leader.rep.key })
            if (match != null) {
                match.first.contents += content
                match.first.maxDistance = maxOf(match.first.maxDistance, match.second)
            } else {
                clusters += Cluster(content)
                tree.add(ph, clusters.lastIndex)
            }
        }
        return clusters
    }

    /** Dodatne provjere za vizualni duplikat: dHash i omjer stranica. */
    private fun visuallySame(a: ScannedFile, b: ScannedFile): Boolean {
        val dA = a.dHash
        val dB = b.dHash
        if (dA != null && dB != null && PerceptualHash.hamming(dA, dB) > ScanSettings.VISUAL_MAX_DHASH_DISTANCE) return false
        return PerceptualHash.aspectClose(a.width, a.height, b.width, b.height, ScanSettings.VISUAL_ASPECT_TOLERANCE)
    }

    private fun makeGroup(type: GroupType, category: FileCategory, contents: List<Content>, maxDistance: Int?): DuplicateGroup {
        val members = contents.flatMapIndexed { idx, c -> c.files.map { GroupMember(it.key, idx) } }
        return DuplicateGroup(groupId(type, members), type, category, members, maxDistance)
    }

    /** Deterministički ID – ista grupa dobiva isti ID u ponovljenom skeniranju. */
    private fun groupId(type: GroupType, members: List<GroupMember>): String {
        val md = MessageDigest.getInstance("SHA-1")
        md.update(type.name.toByteArray())
        members.map { it.fileKey }.sorted().forEach { md.update(0); md.update(it.toByteArray()) }
        return type.name.lowercase(Locale.ROOT) + "_" + md.digest().take(8).joinToString("") { "%02x".format(it) }
    }
}

/** BK-stablo za brzo pretraživanje hashova po Hammingovoj udaljenosti. */
class BkTree {
    private class Node(val hash: Long, val value: Int) {
        val children = HashMap<Int, Node>()
    }

    private var root: Node? = null

    fun add(hash: Long, value: Int) {
        val r = root ?: run { root = Node(hash, value); return }
        var node: Node = r
        while (true) {
            val d = PerceptualHash.hamming(node.hash, hash)
            val child = node.children[d]
            if (child == null) {
                node.children[d] = Node(hash, value)
                return
            }
            node = child
        }
    }

    /** Vraća parove (vrijednost, udaljenost) za sve hashove unutar [radius]. */
    fun search(hash: Long, radius: Int): List<Pair<Int, Int>> {
        val out = mutableListOf<Pair<Int, Int>>()
        val r = root ?: return out
        val stack = ArrayDeque<Node>()
        stack.add(r)
        while (stack.isNotEmpty()) {
            val node = stack.removeLast()
            val d = PerceptualHash.hamming(node.hash, hash)
            if (d <= radius) out += node.value to d
            for (k in (d - radius)..(d + radius)) node.children[k]?.let { stack.add(it) }
        }
        return out
    }
}

package hr.smartduplicatecleaner.core.hash

import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sqrt

/**
 * Slika u nijansama sive (vrijednosti 0–255), neovisna o Androidu.
 * Android dio aplikacije dekodira umanjenu sliku i pretvara je u ovaj oblik.
 */
class GrayImage(val width: Int, val height: Int, val pixels: IntArray) {
    init {
        require(width > 0 && height > 0) { "Neispravne dimenzije" }
        require(pixels.size == width * height) { "Broj piksela ne odgovara dimenzijama" }
    }

    operator fun get(x: Int, y: Int): Int = pixels[y * width + x]

    /** Smanjivanje usrednjavanjem površine (box filter) – otporno na šum i kompresiju. */
    fun resize(targetW: Int, targetH: Int): GrayImage {
        val out = IntArray(targetW * targetH)
        for (ty in 0 until targetH) {
            val y0 = ty * height / targetH
            val y1 = maxOf(y0 + 1, (ty + 1) * height / targetH)
            for (tx in 0 until targetW) {
                val x0 = tx * width / targetW
                val x1 = maxOf(x0 + 1, (tx + 1) * width / targetW)
                var sum = 0L
                var count = 0
                for (y in y0 until minOf(y1, height)) {
                    val row = y * width
                    for (x in x0 until minOf(x1, width)) {
                        sum += pixels[row + x]
                        count++
                    }
                }
                out[ty * targetW + tx] = if (count == 0) 0 else (sum / count).toInt()
            }
        }
        return GrayImage(targetW, targetH, out)
    }

    /**
     * Primjena EXIF orijentacije (1–8) kako bi fotografija koja je fizički zakrenuta
     * i ona koja je zakrenuta samo EXIF oznakom dale isti hash.
     */
    fun applyExifOrientation(orientation: Int): GrayImage = when (orientation) {
        2 -> transform(width, height) { x, y -> this[width - 1 - x, y] }
        3 -> transform(width, height) { x, y -> this[width - 1 - x, height - 1 - y] }
        4 -> transform(width, height) { x, y -> this[x, height - 1 - y] }
        5 -> transform(height, width) { x, y -> this[y, x] }
        6 -> transform(height, width) { x, y -> this[y, height - 1 - x] }
        7 -> transform(height, width) { x, y -> this[width - 1 - y, height - 1 - x] }
        8 -> transform(height, width) { x, y -> this[width - 1 - y, x] }
        else -> this
    }

    private inline fun transform(w: Int, h: Int, src: (Int, Int) -> Int): GrayImage {
        val out = IntArray(w * h)
        for (y in 0 until h) for (x in 0 until w) out[y * w + x] = src(x, y)
        return GrayImage(w, h, out)
    }

    companion object {
        /** Pretvorba ARGB piksela u sivu (ITU-R BT.601 luminancija). */
        fun fromArgb(width: Int, height: Int, argb: IntArray): GrayImage {
            val gray = IntArray(argb.size)
            for (i in argb.indices) {
                val c = argb[i]
                val r = (c shr 16) and 0xFF
                val g = (c shr 8) and 0xFF
                val b = c and 0xFF
                gray[i] = (r * 299 + g * 587 + b * 114) / 1000
            }
            return GrayImage(width, height, gray)
        }
    }
}

/** Perceptualni hashovi: slične slike daju hashove male Hammingove udaljenosti. */
object PerceptualHash {
    private const val DCT_SIZE = 32
    private const val LOW = 8

    private val cosTable: Array<DoubleArray> = Array(DCT_SIZE) { u ->
        DoubleArray(DCT_SIZE) { x -> cos((2 * x + 1) * u * PI / (2 * DCT_SIZE)) }
    }

    /** dHash: uspoređuje susjedne piksele u slici 9×8 (gradijent svjetline). */
    fun dHash(image: GrayImage): Long {
        val small = image.resize(9, 8)
        var hash = 0L
        var bit = 0
        for (y in 0 until 8) for (x in 0 until 8) {
            if (small[x, y] < small[x + 1, y]) hash = hash or (1L shl bit)
            bit++
        }
        return hash
    }

    /** pHash: niske frekvencije 2D DCT-a slike 32×32 uspoređene s medijanom. */
    fun pHash(image: GrayImage): Long {
        val small = image.resize(DCT_SIZE, DCT_SIZE)
        val input = Array(DCT_SIZE) { y -> DoubleArray(DCT_SIZE) { x -> small[x, y].toDouble() } }
        val dct = dct2d(input)
        val values = DoubleArray(LOW * LOW)
        var i = 0
        for (v in 0 until LOW) for (u in 0 until LOW) values[i++] = dct[v][u]
        // Medijan bez DC koeficijenta (prosječna svjetlina ne smije dominirati).
        val sorted = values.copyOfRange(1, values.size).sorted()
        val median = (sorted[sorted.size / 2 - 1] + sorted[sorted.size / 2]) / 2.0
        var hash = 0L
        for (k in values.indices) if (values[k] > median) hash = hash or (1L shl k)
        return hash
    }

    private fun dct2d(input: Array<DoubleArray>): Array<DoubleArray> {
        val n = DCT_SIZE
        // Računamo samo prvih LOW koeficijenata u svakoj dimenziji – to je sve što hash koristi.
        val rows = Array(n) { DoubleArray(LOW) }
        for (y in 0 until n) for (u in 0 until LOW) {
            var s = 0.0
            for (x in 0 until n) s += input[y][x] * cosTable[u][x]
            rows[y][u] = s * alpha(u)
        }
        val out = Array(LOW) { DoubleArray(LOW) }
        for (u in 0 until LOW) for (v in 0 until LOW) {
            var s = 0.0
            for (y in 0 until n) s += rows[y][u] * cosTable[v][y]
            out[v][u] = s * alpha(v)
        }
        return out
    }

    private fun alpha(k: Int): Double = if (k == 0) sqrt(1.0 / DCT_SIZE) else sqrt(2.0 / DCT_SIZE)

    fun hamming(a: Long, b: Long): Int = java.lang.Long.bitCount(a xor b)

    /** Postotak sličnosti iz Hammingove udaljenosti (64 bita). */
    fun similarityPercent(distance: Int): Int = ((64 - distance) * 100 + 32) / 64

    /** Jesu li omjeri stranica dovoljno slični (izbjegava spajanje izrezanih verzija s originalom). */
    fun aspectClose(w1: Int?, h1: Int?, w2: Int?, h2: Int?, tolerance: Double): Boolean {
        if (w1 == null || h1 == null || w2 == null || h2 == null || h1 == 0 || h2 == 0) return true
        val a1 = w1.toDouble() / h1
        val a2 = w2.toDouble() / h2
        // Ista fotografija može biti zakrenuta (portret/pejzaž) u metapodacima.
        val direct = abs(a1 - a2) / maxOf(a1, a2)
        val rotated = abs(a1 - 1.0 / a2) / maxOf(a1, 1.0 / a2)
        return minOf(direct, rotated) <= tolerance
    }
}

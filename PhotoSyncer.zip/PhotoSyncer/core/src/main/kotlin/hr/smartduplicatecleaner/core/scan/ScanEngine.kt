package hr.smartduplicatecleaner.core.scan

import hr.smartduplicatecleaner.core.hash.GrayImage
import hr.smartduplicatecleaner.core.hash.PerceptualHash
import hr.smartduplicatecleaner.core.hash.Sha256
import hr.smartduplicatecleaner.core.logic.DuplicateGrouper
import hr.smartduplicatecleaner.core.logic.GroupDecision
import hr.smartduplicatecleaner.core.logic.KeepSelector
import hr.smartduplicatecleaner.core.model.DateSource
import hr.smartduplicatecleaner.core.model.DuplicateGroup
import hr.smartduplicatecleaner.core.model.FileCategory
import hr.smartduplicatecleaner.core.model.KeepRules
import hr.smartduplicatecleaner.core.model.ScanSettings
import hr.smartduplicatecleaner.core.model.ScannedFile
import hr.smartduplicatecleaner.core.model.SourceType
import java.io.InputStream
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.ExecutionException
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong

/** Signal za otkazivanje dugotrajnih operacija. */
fun interface CancelToken {
    fun isCancelled(): Boolean

    fun throwIfCancelled() {
        if (isCancelled()) throw ScanCancelledException()
    }

    companion object {
        val NONE = CancelToken { false }
    }
}

class ScanCancelledException : RuntimeException("Skeniranje je otkazano")

enum class WarningKind {
    /** Dopuštenje nije odobreno – izvor nije skeniran. */
    PERMISSION_DENIED,
    /** Mapa ili izvor nisu dostupni (npr. izvađena SD kartica, opozvan pristup mapi). */
    INACCESSIBLE,
    /** Odobren je samo djelomičan pristup (npr. "Odabrane fotografije" na Androidu 14+). */
    PARTIAL_ACCESS,
    /** Neke datoteke nije bilo moguće pročitati. */
    UNREADABLE_FILES,
    /** Neke slike nije bilo moguće dekodirati – za njih radi samo točna (SHA-256) usporedba. */
    UNDECODABLE_IMAGES,
    ERROR
}

data class SourceWarning(val sourceId: String, val kind: WarningKind, val detail: String? = null)

/** Izvor datoteka (MediaStore, SAF mapa, datotečni sustav). */
interface FileSource {
    val id: String

    /**
     * Nabraja datoteke. Smije baciti [SecurityException] ako dopuštenje nije odobreno –
     * skeniranje se tada nastavlja s ostalim izvorima, a korisnik dobiva upozorenje.
     */
    fun enumerate(cancel: CancelToken, emit: (ScannedFile) -> Unit, warn: (SourceWarning) -> Unit)
}

/** Rezultat analize slike: umanjena siva slika s primijenjenom orijentacijom i stvarne dimenzije. */
class ImageAnalysis(val gray: GrayImage, val width: Int, val height: Int)

data class ImageMetadata(val dateTakenMillis: Long?, val width: Int?, val height: Int?)

/** Pristup sadržaju datoteka – implementira ga Android dio. */
interface ContentAccess {
    /** Otvara izvorne bajtove datoteke (za SHA-256). */
    fun open(file: ScannedFile): InputStream
    /** Dekodira umanjenu sliku; null ako format nije podržan. */
    fun analyzeImage(file: ScannedFile): ImageAnalysis?
    /** Čita EXIF metapodatke (datum snimanja, dimenzije). */
    fun readMetadata(file: ScannedFile): ImageMetadata?
}

data class CachedHashes(val sha256: String?, val pHash: Long?, val dHash: Long?, val width: Int?, val height: Int?)

/**
 * Predmemorija hashova – ubrzava ponovno skeniranje nepromijenjenih datoteka.
 * Implementacija mora: (1) vratiti zapis samo ako se veličina i datum izmjene nisu promijenili,
 * (2) u [store] spajati podatke – polje null ne smije prebrisati postojeću vrijednost.
 */
interface HashCache {
    fun lookup(file: ScannedFile): CachedHashes?
    fun store(file: ScannedFile, hashes: CachedHashes)

    object None : HashCache {
        override fun lookup(file: ScannedFile): CachedHashes? = null
        override fun store(file: ScannedFile, hashes: CachedHashes) {}
    }
}

enum class ScanPhase { LISTING, HASHING, ANALYZING_IMAGES, GROUPING, FINISHED }

data class ScanProgress(
    val phase: ScanPhase,
    val filesFound: Int,
    val processed: Int,
    val total: Int,
    val duplicatesFound: Int,
    val reclaimableBytes: Long
)

data class ScanStats(
    val filesListed: Int,
    val filesAnalyzed: Int,
    val analyzedBytes: Long,
    val skippedBySize: Int,
    val skippedBySizeBytes: Long,
    /** Preskočene (prevelike) datoteke koje dijele naziv ili veličinu s nekom drugom – mogući duplikati. */
    val skippedPotentialDuplicates: Int,
    val skippedByCategory: Int,
    val skippedByFolder: Int,
    /** Datoteke izvan odabranog vremenskog intervala. */
    val skippedByDate: Int,
    val emptyFiles: Int,
    val unreadableFiles: Int,
    val undecodableImages: Int,
    val duplicateFiles: Int,
    val reclaimableBytes: Long,
    val groupCount: Int
)

data class ScanResult(
    /** Samo datoteke koje su članovi neke grupe. */
    val files: Map<String, ScannedFile>,
    val groups: List<DuplicateGroup>,
    val decisions: Map<String, GroupDecision>,
    val stats: ScanStats,
    val warnings: List<SourceWarning>
)

/**
 * Cjelokupni postupak skeniranja, neovisan o Androidu:
 * nabrajanje → filtriranje (veličina, kategorija, mape) → uklanjanje istih fizičkih datoteka →
 * SHA-256 (samo za datoteke iste veličine) → perceptualni hash slika → grupiranje →
 * EXIF metapodaci članova grupa → automatski prijedlog.
 */
class ScanEngine(
    private val sources: List<FileSource>,
    private val content: ContentAccess,
    private val cache: HashCache = HashCache.None
) {
    fun run(
        settings: ScanSettings,
        rules: KeepRules,
        cancel: CancelToken,
        onProgress: (ScanProgress) -> Unit = {}
    ): ScanResult {
        val warnings = mutableListOf<SourceWarning>()
        val unique = LinkedHashMap<String, ScannedFile>()
        var listed = 0
        val dupCounter = AtomicInteger(0)
        val reclaimCounter = AtomicLong(0)

        // 1) Nabrajanje; ista fizička datoteka (isti ključ) uzima se samo jednom.
        for (source in sources) {
            cancel.throwIfCancelled()
            try {
                source.enumerate(cancel, { file ->
                    listed++
                    unique.putIfAbsent(file.key, file)
                    if (listed % 200 == 0) onProgress(ScanProgress(ScanPhase.LISTING, listed, 0, 0, 0, 0))
                }, { warnings += it })
            } catch (e: ScanCancelledException) {
                throw e
            } catch (e: SecurityException) {
                warnings += SourceWarning(source.id, WarningKind.PERMISSION_DENIED, e.message)
            } catch (e: Exception) {
                warnings += SourceWarning(source.id, WarningKind.INACCESSIBLE, e.message)
            }
        }
        onProgress(ScanProgress(ScanPhase.LISTING, listed, 0, 0, 0, 0))

        // 2) Filtriranje.
        val considered = mutableListOf<ScannedFile>()
        val skippedBySizeList = mutableListOf<ScannedFile>()
        var skippedCategory = 0
        var skippedFolder = 0
        var skippedDate = 0
        var empty = 0
        val dirs = settings.includedRelativeDirs.map { normalizeDir(it) }
        for (f in unique.values) {
            when {
                f.category !in settings.categories -> skippedCategory++
                dirs.isNotEmpty() && f.source != SourceType.SAF_TREE &&
                    dirs.none { normalizeDir(f.relativeDir).startsWith(it) } -> skippedFolder++
                !settings.dateAccepted(f.category, creationDate(f)) -> skippedDate++
                f.sizeBytes <= 0L -> empty++
                settings.maxFileSizeBytes != null && f.sizeBytes > settings.maxFileSizeBytes -> skippedBySizeList += f
                else -> considered += f
            }
        }
        val skippedPotential = countPotentialDuplicates(skippedBySizeList, considered)

        // 3) SHA-256 samo za datoteke koje dijele veličinu s barem jednom drugom datotekom.
        val hashed = ConcurrentHashMap<String, ScannedFile>()
        considered.forEach { hashed[it.key] = it }
        val unreadable = AtomicInteger(0)
        val sizeCandidates = considered.groupBy { it.sizeBytes }.values.filter { it.size >= 2 }.flatten()
        val fullCandidates = ConcurrentHashMap.newKeySet<String>()
        val partials = ConcurrentHashMap<String, String>()
        val processed = AtomicInteger(0)
        val hashTotal = sizeCandidates.size

        parallel(sizeCandidates, settings.parallelism, cancel) { f ->
            val cached = cache.lookup(f)
            if (cached?.sha256 != null) {
                hashed[f.key] = hashed.getValue(f.key).copy(sha256 = cached.sha256)
            } else {
                try {
                    partials[f.key] = "${f.sizeBytes}:" + Sha256.partialHash(content.open(f))
                } catch (e: ScanCancelledException) {
                    throw e
                } catch (e: Exception) {
                    unreadable.incrementAndGet()
                }
            }
            onProgress(ScanProgress(ScanPhase.HASHING, listed, processed.incrementAndGet(), hashTotal, dupCounter.get(), reclaimCounter.get()))
        }
        // Puni hash samo gdje se podudaraju i veličina i početak sadržaja.
        partials.entries.groupBy({ it.value }, { it.key }).values.filter { it.size >= 2 }.flatten().forEach { fullCandidates += it }
        // Datoteke iz predmemorije koje dijele veličinu s datotekom koja ima samo djelomični hash
        // također trebaju puni hash druge strane – dodajemo sve djelomične iz istih veličina.
        val cachedSizes = sizeCandidates.filter { hashed.getValue(it.key).sha256 != null }.map { it.sizeBytes }.toSet()
        partials.keys.filter { hashed.getValue(it).sizeBytes in cachedSizes }.forEach { fullCandidates += it }

        val fullList = fullCandidates.mapNotNull { hashed[it] }
        val shaCount = ConcurrentHashMap<String, AtomicInteger>()
        hashed.values.mapNotNull { it.sha256 }.forEach { shaCount.getOrPut(it) { AtomicInteger() }.incrementAndGet() }
        processed.set(0)
        parallel(fullList, settings.parallelism, cancel) { f ->
            try {
                val sha = Sha256.hash(content.open(f), cancel)
                hashed[f.key] = hashed.getValue(f.key).copy(sha256 = sha)
                val n = shaCount.getOrPut(sha) { AtomicInteger() }.incrementAndGet()
                if (n == 2) dupCounter.addAndGet(2) else if (n > 2) dupCounter.incrementAndGet()
                if (n >= 2) reclaimCounter.addAndGet(f.sizeBytes)
                cache.store(f, CachedHashes(sha, null, null, f.width, f.height))
            } catch (e: ScanCancelledException) {
                throw e
            } catch (e: Exception) {
                unreadable.incrementAndGet()
            }
            onProgress(ScanProgress(ScanPhase.HASHING, listed, processed.incrementAndGet(), fullList.size, dupCounter.get(), reclaimCounter.get()))
        }

        // 4) Perceptualni hash slika – samo kad je vizualna usporedba uključena (inače se preskače, brže je).
        val images = if (!settings.findSimilarPhotos) emptyList() else hashed.values.filter { it.category == FileCategory.IMAGE }
        val undecodable = AtomicInteger(0)
        processed.set(0)
        parallel(images, settings.parallelism, cancel) { f ->
            val current = hashed.getValue(f.key)
            val cached = cache.lookup(f)
            if (cached?.pHash != null && cached.dHash != null) {
                hashed[f.key] = current.copy(
                    pHash = cached.pHash, dHash = cached.dHash,
                    width = current.width ?: cached.width, height = current.height ?: cached.height
                )
            } else {
                try {
                    val analysis = content.analyzeImage(f)
                    if (analysis == null) {
                        undecodable.incrementAndGet()
                    } else {
                        val ph = PerceptualHash.pHash(analysis.gray)
                        val dh = PerceptualHash.dHash(analysis.gray)
                        val updated = current.copy(
                            pHash = ph, dHash = dh,
                            width = current.width ?: analysis.width, height = current.height ?: analysis.height
                        )
                        hashed[f.key] = updated
                        cache.store(f, CachedHashes(updated.sha256, ph, dh, updated.width, updated.height))
                    }
                } catch (e: ScanCancelledException) {
                    throw e
                } catch (e: OutOfMemoryError) {
                    // Pri nedostatku memorije slika se preskače umjesto rušenja aplikacije.
                    undecodable.incrementAndGet()
                } catch (e: Exception) {
                    undecodable.incrementAndGet()
                }
            }
            onProgress(ScanProgress(ScanPhase.ANALYZING_IMAGES, listed, processed.incrementAndGet(), images.size, dupCounter.get(), reclaimCounter.get()))
        }

        // 5) Grupiranje.
        cancel.throwIfCancelled()
        onProgress(ScanProgress(ScanPhase.GROUPING, listed, 0, 0, dupCounter.get(), reclaimCounter.get()))
        val all = hashed.values.sortedBy { it.key }
        val groups = DuplicateGrouper.group(all, settings, cancel)

        // 6) EXIF metapodaci samo za slike u grupama (štedi vrijeme).
        val memberKeys = groups.flatMap { it.fileKeys }.toSet()
        val members = HashMap<String, ScannedFile>()
        for (key in memberKeys) {
            cancel.throwIfCancelled()
            var f = hashed.getValue(key)
            if (f.category == FileCategory.IMAGE) {
                val meta = try { content.readMetadata(f) } catch (e: Exception) { null }
                if (meta != null) {
                    f = f.copy(
                        dateTakenMillis = meta.dateTakenMillis ?: f.dateTakenMillis.takeIf { f.dateTakenSource == DateSource.EXIF },
                        dateTakenSource = when {
                            meta.dateTakenMillis != null -> DateSource.EXIF
                            f.dateTakenSource == DateSource.EXIF -> DateSource.EXIF
                            else -> null
                        },
                        width = f.width ?: meta.width,
                        height = f.height ?: meta.height
                    )
                }
            }
            members[key] = f
        }

        // 7) Automatski prijedlog.
        val decisions = groups.associate { it.id to KeepSelector.decide(it, members, rules) }

        if (unreadable.get() > 0) warnings += SourceWarning("content", WarningKind.UNREADABLE_FILES, unreadable.get().toString())
        if (undecodable.get() > 0) warnings += SourceWarning("images", WarningKind.UNDECODABLE_IMAGES, undecodable.get().toString())

        val partitionKeys = groups.filter { it.allowsAutoSuggestion }.flatMap { it.fileKeys }.toSet()
        val reclaimable = decisions.values.flatMap { it.suggestedDeleteKeys }.toSet().sumOf { members.getValue(it).sizeBytes }
        val stats = ScanStats(
            filesListed = listed,
            filesAnalyzed = considered.size,
            analyzedBytes = considered.sumOf { it.sizeBytes },
            skippedBySize = skippedBySizeList.size,
            skippedBySizeBytes = skippedBySizeList.sumOf { it.sizeBytes },
            skippedPotentialDuplicates = skippedPotential,
            skippedByCategory = skippedCategory,
            skippedByFolder = skippedFolder,
            skippedByDate = skippedDate,
            emptyFiles = empty,
            unreadableFiles = unreadable.get(),
            undecodableImages = undecodable.get(),
            duplicateFiles = partitionKeys.size,
            reclaimableBytes = reclaimable,
            groupCount = groups.size
        )
        onProgress(ScanProgress(ScanPhase.FINISHED, listed, 0, 0, partitionKeys.size, reclaimable))
        return ScanResult(members, groups, decisions, stats, warnings)
    }

    /**
     * Datum nastanka za vremenski filtar: najraniji poznati datum (snimanja ili posljednje izmjene).
     * Datum dodavanja na uređaj (≈ kopiranje) se namjerno ne koristi.
     */
    private fun creationDate(f: ScannedFile): Long? =
        listOfNotNull(f.dateTakenMillis, f.dateModifiedMillis).filter { it > 0 }.minOrNull()

    private fun normalizeDir(dir: String): String =
        dir.trim('/').lowercase(Locale.ROOT) + "/"

    /** Preskočene datoteke koje bi mogle biti duplikati: ista veličina ili isti naziv kao neka druga. */
    private fun countPotentialDuplicates(skipped: List<ScannedFile>, considered: List<ScannedFile>): Int {
        if (skipped.isEmpty()) return 0
        val sizeCounts = skipped.groupingBy { it.sizeBytes }.eachCount()
        val names = HashMap<String, Int>()
        (skipped + considered).forEach { names.merge(it.name.lowercase(Locale.ROOT), 1, Int::plus) }
        return skipped.count { (sizeCounts[it.sizeBytes] ?: 0) >= 2 || (names[it.name.lowercase(Locale.ROOT)] ?: 0) >= 2 }
    }

    /** Ograničena paralelizacija uz podršku za otkazivanje. */
    private fun <T> parallel(items: List<T>, threads: Int, cancel: CancelToken, action: (T) -> Unit) {
        if (items.isEmpty()) return
        val n = threads.coerceIn(1, 4)
        if (n == 1) {
            items.forEach { cancel.throwIfCancelled(); action(it) }
            return
        }
        val pool = Executors.newFixedThreadPool(n)
        try {
            val futures = items.map { item ->
                pool.submit {
                    cancel.throwIfCancelled()
                    action(item)
                }
            }
            for (f in futures) {
                if (cancel.isCancelled()) throw ScanCancelledException()
                try {
                    f.get()
                } catch (e: ExecutionException) {
                    val cause = e.cause
                    if (cause is ScanCancelledException) throw cause
                    if (cause is Error) throw cause
                    throw RuntimeException(cause)
                }
            }
        } finally {
            pool.shutdownNow()
            pool.awaitTermination(5, TimeUnit.SECONDS)
        }
    }
}

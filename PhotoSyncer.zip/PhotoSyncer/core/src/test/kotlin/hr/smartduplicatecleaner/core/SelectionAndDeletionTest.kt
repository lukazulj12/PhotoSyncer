package hr.smartduplicatecleaner.core

import hr.smartduplicatecleaner.core.Fixtures.file
import hr.smartduplicatecleaner.core.logic.DeleteOutcome
import hr.smartduplicatecleaner.core.logic.DeletionPlanner
import hr.smartduplicatecleaner.core.logic.DeletionRunner
import hr.smartduplicatecleaner.core.logic.FailureReason
import hr.smartduplicatecleaner.core.logic.FileDeleter
import hr.smartduplicatecleaner.core.logic.GroupDecision
import hr.smartduplicatecleaner.core.logic.MemberDecision
import hr.smartduplicatecleaner.core.logic.PlanResult
import hr.smartduplicatecleaner.core.logic.SelectionState
import hr.smartduplicatecleaner.core.logic.Suggestion
import hr.smartduplicatecleaner.core.model.DuplicateGroup
import hr.smartduplicatecleaner.core.model.FileCategory
import hr.smartduplicatecleaner.core.model.GroupMember
import hr.smartduplicatecleaner.core.model.GroupType
import hr.smartduplicatecleaner.core.model.ScannedFile
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class SelectionAndDeletionTest {
    private val a = file("DCIM/a.jpg", 100)
    private val b = file("Pictures/a.jpg", 100)
    private val c = file("Download/a.jpg", 100)
    private val x = file("Download/x.jpg", 90)
    private val files: Map<String, ScannedFile> = listOf(a, b, c, x).associateBy { it.key }

    private fun group(id: String, type: GroupType, vararg f: ScannedFile) =
        DuplicateGroup(id, type, FileCategory.IMAGE, f.mapIndexed { i, it -> GroupMember(it.key, if (type == GroupType.EXACT) 0 else i) })

    private val exact = group("g1", GroupType.EXACT, a, b, c)

    // Scenarij 9 – ručna promjena automatskog odabira
    @Test
    fun manualChangeOfAutomaticSelection() {
        val decision = GroupDecision(
            "g1",
            listOf(
                MemberDecision(a.key, Suggestion.KEEP, emptyList()),
                MemberDecision(b.key, Suggestion.DELETE, emptyList()),
                MemberDecision(c.key, Suggestion.DELETE, emptyList())
            ),
            needsManual = false, notes = emptyList()
        )
        val s = SelectionState(listOf(exact))
        assertEquals(2, s.applySuggestions(listOf(decision), onlyConfirmed = true))
        assertEquals(setOf(b.key, c.key), s.marked)
        // Korisnik jednim dodirom odabire drugu datoteku za čuvanje.
        assertEquals(0, s.keepOnly("g1", c.key))
        assertEquals(setOf(a.key, b.key), s.marked)
        // Poništavanje pojedinačne oznake.
        assertEquals(SelectionState.Result.OK, s.toggle(b.key))
        assertEquals(setOf(a.key), s.marked)
    }

    // Scenarij 10 – pokušaj brisanja svih datoteka iz jedne grupe
    @Test
    fun cannotMarkAllFilesInGroup() {
        val s = SelectionState(listOf(exact))
        assertEquals(SelectionState.Result.OK, s.setMarked(a.key, true))
        assertEquals(SelectionState.Result.OK, s.setMarked(b.key, true))
        assertEquals(SelectionState.Result.BLOCKED_LAST_FILE, s.setMarked(c.key, true))
        assertFalse(s.isMarked(c.key))
        assertTrue(s.violations().isEmpty())
        val plan = (DeletionPlanner.build(s, files) as PlanResult.Ready).plan
        assertEquals(setOf(a.key, b.key), plan.keys)
    }

    @Test
    fun corruptedSavedState_withAllMarked_isSanitized() {
        val s = SelectionState(listOf(exact), marked = setOf(a.key, b.key, c.key))
        assertTrue(s.marked.isEmpty())
    }

    @Test
    fun crossGroupProtection_fileInTwoGroups() {
        // b je u EXACT grupi s a, a i u SAME_NAME grupi s x.
        val g1 = group("g1", GroupType.EXACT, a, b)
        val g2 = group("g2", GroupType.SAME_NAME, b, x)
        val s = SelectionState(listOf(g1, g2))
        assertEquals(SelectionState.Result.OK, s.setMarked(x.key, true))
        // "Zadrži samo a" bi označilo b – ali tada bi grupa g2 ostala bez ijedne datoteke.
        val skipped = s.keepOnly("g1", a.key)
        assertEquals(1, skipped)
        assertFalse(s.isMarked(b.key))
        assertTrue(s.violations().isEmpty())
    }

    @Test
    fun onlyConfirmed_ignoresVisualGroups() {
        val g = group("v1", GroupType.VISUAL, a, x)
        val d = GroupDecision("v1", listOf(MemberDecision(a.key, Suggestion.KEEP, emptyList()), MemberDecision(x.key, Suggestion.DELETE, emptyList())), false, emptyList())
        val s = SelectionState(listOf(g))
        assertEquals(0, s.applySuggestions(listOf(d), onlyConfirmed = true))
        assertEquals(1, s.applySuggestions(listOf(d), onlyConfirmed = false))
    }

    @Test
    fun undecidedGroups_neverAutoMarked() {
        val d = GroupDecision("g1", listOf(MemberDecision(a.key, Suggestion.UNDECIDED, emptyList()), MemberDecision(b.key, Suggestion.UNDECIDED, emptyList()), MemberDecision(c.key, Suggestion.UNDECIDED, emptyList())), true, emptyList())
        val s = SelectionState(listOf(exact))
        assertEquals(0, s.applySuggestions(listOf(d), onlyConfirmed = false))
        assertTrue(s.marked.isEmpty())
        assertEquals(PlanResult.Empty, DeletionPlanner.build(s, files))
    }

    @Test
    fun planRejectsUnknownFiles() {
        val s = SelectionState(listOf(exact))
        s.setMarked(a.key, true)
        val r = DeletionPlanner.build(s, files - a.key)
        assertTrue(r is PlanResult.Rejected)
    }

    // Glavni sigurnosni test: brišu se ISKLJUČIVO označene i potvrđene datoteke.
    @Test
    fun runnerDeletesOnlyConfirmedFiles() {
        val s = SelectionState(listOf(exact))
        s.setMarked(b.key, true)
        val plan = (DeletionPlanner.build(s, files) as PlanResult.Ready).plan
        val deleted = mutableListOf<String>()
        s.setMarked(c.key, true) // promjena NAKON potvrde ne smije utjecati na plan
        val report = DeletionRunner.run(plan, FileDeleter { deleted += it.key; DeleteOutcome.Done() }, recoverable = true)
        assertEquals(listOf(b.key), deleted)
        assertEquals(1, report.succeeded.size)
        assertEquals(100L, report.freedBytes)
    }

    // Scenarij 12 – pogreška tijekom brisanja
    @Test
    fun errorsDuringDeletion_areReported_andDoNotStopOthers() {
        val g = group("g", GroupType.EXACT, a, b, c, x)
        val s = SelectionState(listOf(g))
        s.setMarked(a.key, true); s.setMarked(b.key, true); s.setMarked(c.key, true)
        val plan = (DeletionPlanner.build(s, files) as PlanResult.Ready).plan
        val report = DeletionRunner.run(
            plan,
            FileDeleter {
                when (it.key) {
                    a.key -> throw SecurityException("nema dopuštenja")
                    b.key -> DeleteOutcome.Failed(FailureReason.NOT_FOUND)
                    else -> DeleteOutcome.Done("rec-1")
                }
            },
            recoverable = false
        )
        assertEquals(listOf(c.key), report.succeeded.map { it.key })
        assertEquals(2, report.failed.size)
        assertTrue(report.failed.any { it.first.key == a.key && it.second.reason == FailureReason.PERMISSION_DENIED })
    }

    @Test
    fun changedSinceScan_isNotDeleted() {
        val s = SelectionState(listOf(exact))
        s.setMarked(a.key, true)
        val plan = (DeletionPlanner.build(s, files) as PlanResult.Ready).plan
        var calls = 0
        val report = DeletionRunner.run(plan, FileDeleter { calls++; DeleteOutcome.Done() }, true,
            stillValid = { FailureReason.CHANGED_SINCE_SCAN })
        assertEquals(0, calls)
        assertEquals(FailureReason.CHANGED_SINCE_SCAN, report.failed.single().second.reason)
    }
}

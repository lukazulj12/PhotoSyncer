package hr.smartduplicatecleaner.core

import hr.smartduplicatecleaner.core.Fixtures.file
import hr.smartduplicatecleaner.core.logic.DeletionPlanner
import hr.smartduplicatecleaner.core.logic.KeepSelector
import hr.smartduplicatecleaner.core.logic.PlanResult
import hr.smartduplicatecleaner.core.logic.SelectionState
import hr.smartduplicatecleaner.core.logic.Suggestion
import hr.smartduplicatecleaner.core.model.DuplicateGroup
import hr.smartduplicatecleaner.core.model.FileCategory
import hr.smartduplicatecleaner.core.model.GroupMember
import hr.smartduplicatecleaner.core.model.GroupType
import hr.smartduplicatecleaner.core.model.KeepRules
import hr.smartduplicatecleaner.core.model.SameNameMode
import hr.smartduplicatecleaner.core.model.ScannedFile
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/** Pravila za grupe "Isti naziv" i brisanje samo u odabranoj kategoriji. */
class SameNameAndScopeTest {
    private fun sameName(id: String, vararg f: ScannedFile) =
        DuplicateGroup(id, GroupType.SAME_NAME, f.first().category, f.mapIndexed { i, it -> GroupMember(it.key, i) })

    private val rules = KeepRules(preferredFolders = listOf("DCIM/Camera"), demotedFolders = listOf("Download"))

    // Isti videozapis kojem je promijenjen datum (ista veličina, različit hash) u DCIM/Camera i Download.
    private val camVideo = file("DCIM/Camera/VID_20250705_105923.mp4", 50_000_000, width = 1920, height = 1080)
    private val dlVideo = file("Download/VID_20250705_105923.mp4", 50_000_000, width = 1920, height = 1080)
    // Druga fotografija istog generičkog naziva – posve drukčija veličina.
    private val otherA = file("DCIM/Camera/IMG_0001.jpg", 3_100_000, width = 4000, height = 3000)
    private val otherB = file("Download/IMG_0001.jpg", 2_400_000, width = 4000, height = 3000)

    @Test
    fun nearIdentical_rulesApplied_folderPriority() {
        val g = sameName("s1", camVideo, dlVideo)
        val d = KeepSelector.decide(g, listOf(camVideo, dlVideo).associateBy { it.key }, rules)
        assertEquals(false, d.needsManual)
        assertEquals(setOf(dlVideo.key), d.suggestedDeleteKeys)
        assertEquals(Suggestion.KEEP, d.members.first { it.fileKey == camVideo.key }.suggestion)
        // Automatsko označavanje (kao nakon skeniranja).
        val s = SelectionState(listOf(g))
        assertEquals(1, s.applySuggestions(listOf(d), onlyConfirmed = false))
        assertEquals(setOf(dlVideo.key), s.marked)
        // "Samo potvrđene" (SHA-256) i dalje ne dira grupe istog naziva.
        val s2 = SelectionState(listOf(g))
        assertEquals(0, s2.applySuggestions(listOf(d), onlyConfirmed = true))
    }

    @Test
    fun differentFilesWithSameName_notMarked_inSafeMode() {
        val g = sameName("s2", otherA, otherB)
        val d = KeepSelector.decide(g, listOf(otherA, otherB).associateBy { it.key }, rules)
        assertTrue(d.needsManual)
        assertTrue(d.suggestedDeleteKeys.isEmpty())
        // Različita rezolucija = različita datoteka, i uz sličnu veličinu.
        val small = file("Download/IMG_0001.jpg", 3_100_000, width = 1600, height = 1200)
        val d2 = KeepSelector.decide(sameName("s3", otherA, small), listOf(otherA, small).associateBy { it.key }, rules)
        assertTrue(d2.suggestedDeleteKeys.isEmpty())
    }

    @Test
    fun allMode_appliesRulesToEverySameNameFile() {
        val g = sameName("s4", otherA, otherB)
        val d = KeepSelector.decide(g, listOf(otherA, otherB).associateBy { it.key }, rules.copy(sameNameMode = SameNameMode.ALL))
        assertEquals(setOf(otherB.key), d.suggestedDeleteKeys)
        val manual = KeepSelector.decide(g, listOf(otherA, otherB).associateBy { it.key }, rules.copy(sameNameMode = SameNameMode.MANUAL))
        assertTrue(manual.needsManual)
    }

    @Test
    fun mixedGroup_onlyNearIdenticalPartMarked_andEachClusterKeepsOne() {
        val camVideo2 = file("Movies/VID_20250705_105923.mp4", 50_030_000, width = 1080, height = 1920) // zakrenut, +30 KB (< 0,1 %)
        val different = file("Pictures/VID_20250705_105923.mp4", 12_000_000, width = 1280, height = 720)
        val all = listOf(camVideo, dlVideo, camVideo2, different)
        val g = sameName("s5", *all.toTypedArray())
        val d = KeepSelector.decide(g, all.associateBy { it.key }, rules)
        assertEquals(setOf(dlVideo.key, camVideo2.key), d.suggestedDeleteKeys)
        assertEquals(Suggestion.UNDECIDED, d.members.first { it.fileKey == different.key }.suggestion)
    }

    @Test
    fun deletionPlan_onlyInChosenCategory() {
        val a = file("DCIM/a.jpg", 100)
        val b = file("Download/a.jpg", 100)
        val exact = DuplicateGroup("e1", GroupType.EXACT, FileCategory.IMAGE, listOf(GroupMember(a.key, 0), GroupMember(b.key, 0)))
        val g = sameName("s6", camVideo, dlVideo)
        val files = listOf(a, b, camVideo, dlVideo).associateBy { it.key }
        val s = SelectionState(listOf(exact, g))
        s.setMarked(b.key, true)
        s.setMarked(dlVideo.key, true)
        // Brisanje iz kategorije "Isti naziv": samo dlVideo, iako je b također označen.
        val scope = g.fileKeys.toSet()
        val plan = (DeletionPlanner.build(s, files, onlyKeys = scope) as PlanResult.Ready).plan
        assertEquals(setOf(dlVideo.key), plan.keys)
        // Kategorija bez označenih datoteka → prazan plan.
        assertEquals(PlanResult.Empty, DeletionPlanner.build(s, files, onlyKeys = setOf(a.key)))
        // "Sve" → sve označene.
        assertEquals(setOf(b.key, dlVideo.key), (DeletionPlanner.build(s, files) as PlanResult.Ready).plan.keys)
    }
}

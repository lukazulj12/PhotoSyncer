package hr.smartduplicatecleaner.core

import hr.smartduplicatecleaner.core.Fixtures.JAN_2023
import hr.smartduplicatecleaner.core.Fixtures.OCT_2026
import hr.smartduplicatecleaner.core.Fixtures.file
import hr.smartduplicatecleaner.core.format.Formatters
import hr.smartduplicatecleaner.core.format.SizeUnit
import hr.smartduplicatecleaner.core.hash.PerceptualHash
import hr.smartduplicatecleaner.core.hash.Sha256
import hr.smartduplicatecleaner.core.logic.DuplicateGrouper
import hr.smartduplicatecleaner.core.logic.ExifDateParser
import hr.smartduplicatecleaner.core.logic.FileClassifier
import hr.smartduplicatecleaner.core.logic.KeepSelector
import hr.smartduplicatecleaner.core.logic.Reason
import hr.smartduplicatecleaner.core.logic.ReasonCode
import hr.smartduplicatecleaner.core.logic.Suggestion
import hr.smartduplicatecleaner.core.model.CriterionType
import hr.smartduplicatecleaner.core.model.DatePreference
import hr.smartduplicatecleaner.core.model.DuplicateGroup
import hr.smartduplicatecleaner.core.model.FileCategory
import hr.smartduplicatecleaner.core.model.GroupMember
import hr.smartduplicatecleaner.core.model.GroupType
import hr.smartduplicatecleaner.core.model.KeepRules
import hr.smartduplicatecleaner.core.model.ScanSettings
import hr.smartduplicatecleaner.core.model.SizePreference
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.ByteArrayInputStream
import java.time.ZoneId
import java.util.Locale

class HashAndRulesTest {

    @Test
    fun sha256_knownVector() {
        assertEquals(
            "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad",
            Sha256.hash(ByteArrayInputStream("abc".toByteArray()))
        )
    }

    @Test
    fun perceptualHash_robustToScaleAndRecompression_butSeparatesDifferentPhotos() {
        val img = Fixtures.photo(42, 800, 600)
        val small = Fixtures.recompress(img.resize(320, 240))
        val other = Fixtures.photo(43, 800, 600)
        val dSame = PerceptualHash.hamming(PerceptualHash.pHash(img), PerceptualHash.pHash(small))
        val dOther = PerceptualHash.hamming(PerceptualHash.pHash(img), PerceptualHash.pHash(other))
        assertTrue("ista slika: $dSame", dSame <= ScanSettings.VISUAL_MAX_DISTANCE)
        assertTrue("različite slike: $dOther", dOther > 16)
        val ddSame = PerceptualHash.hamming(PerceptualHash.dHash(img), PerceptualHash.dHash(small))
        assertTrue("dHash ista slika: $ddSame", ddSame <= ScanSettings.VISUAL_MAX_DHASH_DISTANCE)
    }

    @Test
    fun exifOrientation_makesRotatedCopiesMatch() {
        val img = Fixtures.photo(5, 300, 200)
        // Fizički zakrenuta za 90° (kao da je spremljena bez EXIF oznake) …
        val rotated = img.applyExifOrientation(6)
        // … i ista slika s EXIF oznakom 8 (vraća za 90°) nakon primjene orijentacije mora biti original.
        val back = rotated.applyExifOrientation(8)
        assertEquals(PerceptualHash.pHash(img), PerceptualHash.pHash(back))
        assertEquals(200, rotated.width)
    }

    @Test
    fun similarGroup_isAdvisoryOnly() {
        val base = Fixtures.photo(77, 400, 300)
        val edited = Fixtures.edit(base)
        val d = PerceptualHash.hamming(PerceptualHash.pHash(base), PerceptualHash.pHash(edited))
        val a = file("DCIM/a.jpg", 1000, width = 400, height = 300).copy(sha256 = "a", pHash = PerceptualHash.pHash(base), dHash = PerceptualHash.dHash(base))
        val b = file("DCIM/b.jpg", 1001, width = 400, height = 300).copy(sha256 = "b", pHash = PerceptualHash.pHash(edited), dHash = PerceptualHash.dHash(edited))
        val groups = DuplicateGrouper.group(listOf(a, b), ScanSettings(similarityPercent = 70))
        // Izmijenjena slika mora biti ili "slična" (ako je unutar praga) – nikad automatski označena.
        if (d > ScanSettings.VISUAL_MAX_DISTANCE && d <= ScanSettings(similarityPercent = 70).similarMaxDistance) {
            val g = groups.single()
            assertEquals(GroupType.SIMILAR, g.type)
            val dec = KeepSelector.decide(g, mapOf(a.key to a, b.key to b), KeepRules())
            assertTrue(dec.needsManual)
            assertTrue(dec.suggestedDeleteKeys.isEmpty())
        }
        val off = DuplicateGrouper.group(listOf(a, b), ScanSettings(findSimilarPhotos = false))
        assertTrue(off.none { it.type == GroupType.SIMILAR })
    }

    private fun g(vararg keys: String) = DuplicateGroup("g", GroupType.EXACT, FileCategory.IMAGE, keys.map { GroupMember(it, 0) })

    @Test
    fun rulePriority_primarySecondaryTertiary() {
        // Primjer iz specifikacije: 1) starija, 2) veća, 3) veća rezolucija.
        val a = file("DCIM/a.jpg", 2000, taken = JAN_2023, width = 100, height = 100)
        val b = file("DCIM/b.jpg", 3000, taken = JAN_2023, width = 100, height = 100)
        val c = file("DCIM/c.jpg", 3000, taken = JAN_2023, width = 200, height = 100)
        val d = file("DCIM/d.jpg", 9000, taken = OCT_2026, width = 900, height = 900)
        val files = listOf(a, b, c, d).associateBy { it.key }
        val dec = KeepSelector.decide(g(a.key, b.key, c.key, d.key), files, KeepRules())
        assertEquals(c.key, dec.members.single { it.suggestion == Suggestion.KEEP }.fileKey)
        assertEquals(ReasonCode.DEL_NEWER, dec.members.single { it.fileKey == d.key }.reasons.first().code)
        assertEquals(ReasonCode.DEL_SMALLER, dec.members.single { it.fileKey == a.key }.reasons.first().code)
        assertEquals(ReasonCode.DEL_LOWER_RES, dec.members.single { it.fileKey == b.key }.reasons.first().code)
        // Promjena redoslijeda: veličina prva → pobjeđuje d.
        val bySize = KeepSelector.decide(g(a.key, b.key, c.key, d.key), files, KeepRules(order = listOf(CriterionType.SIZE, CriterionType.DATE)))
        assertEquals(d.key, bySize.members.single { it.suggestion == Suggestion.KEEP }.fileKey)
    }

    @Test
    fun newerPreference_andDisabledRules() {
        val a = file("DCIM/a.jpg", 2000, taken = JAN_2023)
        val b = file("DCIM/b.jpg", 2000, taken = OCT_2026)
        val files = listOf(a, b).associateBy { it.key }
        val newer = KeepSelector.decide(g(a.key, b.key), files, KeepRules(datePreference = DatePreference.NEWER))
        assertEquals(setOf(a.key), newer.suggestedDeleteKeys)
        val none = KeepSelector.decide(
            g(a.key, b.key), files,
            KeepRules(datePreference = DatePreference.NONE, sizePreference = SizePreference.NONE, preferHigherResolution = false)
        )
        assertTrue(none.needsManual)
        assertTrue(none.suggestedDeleteKeys.isEmpty())
        assertTrue(none.notes.any { it.code == ReasonCode.NO_RULES })
    }

    @Test
    fun missingResolution_skipsCriterion_neverGuesses() {
        val a = file("DCIM/a.jpg", 2000, taken = JAN_2023, width = 4000, height = 3000)
        val b = file("DCIM/b.jpg", 2000, taken = JAN_2023)
        val dec = KeepSelector.decide(g(a.key, b.key), listOf(a, b).associateBy { it.key }, KeepRules())
        assertTrue(dec.notes.any { it.code == ReasonCode.SKIPPED_MISSING_DATA && it.arg == "RESOLUTION" })
        assertTrue(dec.suggestedDeleteKeys.isEmpty())
    }

    @Test
    fun reasonEncoding_roundTrip() {
        val list = listOf(Reason(ReasonCode.KEEP_OLDER, "EXIF"), Reason(ReasonCode.NO_CLEAR_WINNER))
        assertEquals(list, Reason.decodeList(Reason.encodeList(list)))
    }

    @Test
    fun exifDateParser_validatesValues() {
        val zone = ZoneId.of("Europe/Zagreb")
        val now = OCT_2026 + 1000
        assertEquals(1_673_773_200_000L, ExifDateParser.parse("2023:01:15 10:00:00", null, zone, now))
        assertEquals(JAN_2023, ExifDateParser.parse("2023:01:15 10:00:00", "+00:00", zone, now))
        assertNull(ExifDateParser.parse("0000:00:00 00:00:00", null, zone, now))
        assertNull(ExifDateParser.parse("1980:01:01 00:00:00", null, zone, now))
        assertNull(ExifDateParser.parse("2031:01:01 00:00:00", null, zone, now))
        assertNull(ExifDateParser.parse("smeće", null, zone, now))
        assertNull(ExifDateParser.parse(null, null, zone, now))
    }

    @Test
    fun formatters() {
        val hr = Locale.forLanguageTag("hr")
        assertEquals("4,8 MB", Formatters.size(4_800_000, SizeUnit.AUTO, hr))
        assertEquals("4.8 MB", Formatters.size(4_800_000, SizeUnit.AUTO, Locale.ENGLISH))
        assertEquals("4.800,0 KB", Formatters.size(4_800_000, SizeUnit.KB, hr))
        assertEquals("512 B", Formatters.size(512, SizeUnit.AUTO, hr))
        assertEquals("1,50 GB", Formatters.size(1_500_000_000, SizeUnit.GB, hr))
        assertEquals("15.01.2023 11:00", Formatters.dateTime(JAN_2023, true, hr, ZoneId.of("Europe/Zagreb")))
        assertEquals(12_500_000L, Formatters.parseMegabytes("12,5"))
        assertNull(Formatters.parseMegabytes("-3"))
        assertNull(Formatters.parseMegabytes("abc"))
    }

    @Test
    fun classifier() {
        assertEquals(FileCategory.IMAGE, FileClassifier.classify("a.HEIC", null))
        assertEquals(FileCategory.VIDEO, FileClassifier.classify("a.mkv", null))
        assertEquals(FileCategory.AUDIO, FileClassifier.classify("a.flac", null))
        assertEquals(FileCategory.DOCUMENT, FileClassifier.classify("a.docx", null))
        assertEquals(FileCategory.ARCHIVE, FileClassifier.classify("a.7z", null))
        assertEquals(FileCategory.OTHER, FileClassifier.classify("a.xyz", null))
        assertEquals(FileCategory.IMAGE, FileClassifier.classify("bez_ekstenzije", "image/jpeg"))
    }

    @Test
    fun similarityThreshold_mapping() {
        assertEquals(9, ScanSettings(similarityPercent = 85).similarMaxDistance)
        assertEquals(7, ScanSettings(similarityPercent = 99).similarMaxDistance)
        assertEquals(100, PerceptualHash.similarityPercent(0))
    }
}

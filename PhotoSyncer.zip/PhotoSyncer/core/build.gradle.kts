import org.jetbrains.kotlin.gradle.dsl.JvmTarget

// Čisti Kotlin modul: logika prepoznavanja duplikata, pravila odabira i sigurnost brisanja.
// Ne ovisi o Androidu, pa se testovi izvršavaju na običnom JVM-u (./gradlew :core:test).
plugins {
    alias(libs.plugins.kotlin.jvm)
}

java {
    sourceCompatibility = JavaVersion.VERSION_17
    targetCompatibility = JavaVersion.VERSION_17
}

kotlin {
    compilerOptions { jvmTarget.set(JvmTarget.JVM_17) }
}

dependencies {
    testImplementation(libs.junit)
}

# Pravila privatnosti – PhotoSyncer

*Vrijedi od: 10. 11. 2026.*

PhotoSyncer prenosi datoteke između dva korisnikova mobitela, ispravlja datume fotografija i videozapisa prema njihovim
nazivima te pronalazi i uklanja duplicirane datoteke.

**Podaci koje developer prikuplja: nikakvi.**

- Aplikacija nema registraciju, oglase, analitiku ni alate trećih strana za praćenje i ne šalje podatke developeru ni bilo kojem poslužitelju.
- Sva obrada (usporedba datoteka, prepoznavanje datuma) odvija se **lokalno na uređaju**.
- **Prijenos između mobitela:** datoteke koje korisnik odabere šalju se izravno s jednog njegovog mobitela na drugi kroz lokalnu
  mrežu (žarišna točka jednog od mobitela ili zajednička Wi-Fi mreža), bez interneta i bez posrednika. Kako bi stari mobitel pronašao
  novi, aplikacija u lokalnoj mreži šalje kratki upit; odgovor sadrži samo adresu i model mobitela primatelja. Prijenos je zaštićen
  kodom od 4 znamenke koji se prikazuje samo na mobitelu primatelju i nikad se ne šalje mrežom; nakon 10 pogrešnih pokušaja primanje
  se zaustavlja. Dopuštenje za internet koristi se isključivo za tu lokalnu vezu.
- Rezultati skeniranja i postavke spremaju se samo u privatnu pohranu aplikacije i brišu se deinstalacijom.
- Datoteke se brišu ili mijenjaju (datumi) **samo** nakon izričite potvrde korisnika.

**Dopuštenja:** pristup fotografijama, videozapisima i audiozapisima (pronalaženje duplikata, ispravak datuma, slanje, spremanje u iste
mape); pristup lokaciji u medijima (usporedba i prijenos izvornih datoteka – lokacija se ne čita i ne prikazuje); stanje mreže i Wi-Fi-ja
te primanje lokalnih upita (lokalna veza između mobitela); obavijesti i rad u pozadini (napredak skeniranja i prijenosa); popis
instaliranih aplikacija s ikonom (samo ako korisnik odabere prijenos aplikacija). Aplikacija ne traži pristup lokaciji uređaja.

**Kontakt:** lukafrane.zulj@gmail.com

---

# Privacy Policy – PhotoSyncer

*Effective: 10 November 2026.*

PhotoSyncer transfers files between two of the user's phones, fixes photo and video dates based on their file names, and finds and
removes duplicate files.

**Data collected by the developer: none.**

- No accounts, ads, analytics or third-party tracking. No data is sent to the developer or to any server.
- All processing (file comparison, date recognition) happens **locally on the device**.
- **Phone-to-phone transfer:** files chosen by the user are sent directly from one of the user's phones to the other over the local
  network (one phone's hotspot or a shared Wi-Fi network), without the internet or any intermediary. To let the old phone find the new
  one, the app sends a short query on the local network; the reply contains only the receiving phone's address and model. The transfer is
  protected by a 4-digit code that is shown only on the receiving phone and is never sent over the network; after 10 wrong attempts the
  receiver stops. The internet permission is used only for this local connection.
- Scan results and settings are stored only in the app's private storage and are removed when the app is uninstalled.
- Files are deleted or modified (dates) **only** after the user's explicit confirmation.

**Permissions:** photos, videos and audio (finding duplicates, fixing dates, sending, saving into matching folders); media location
(comparing and transferring original files – location is never read or shown); network and Wi-Fi state and receiving local queries (local
connection between the phones); notifications and background work (scan and transfer progress); list of installed launchable apps (only if
the user chooses to transfer apps). The app does not request access to the device location.

**Contact:** lukafrane.zulj@gmail.com
